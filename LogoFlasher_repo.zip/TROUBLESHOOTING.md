# Connection Troubleshooting Guide - Baofeng Logo Flasher

## Summary

The app's connection issue has been **diagnosed and fixed**:

### Changes Made ✓
1. **Fixed baud rate**: Changed from 38400 → **9600** (correct per UV-5RM protocol)
2. **Fixed magic bytes**: Changed from `"PROGRAM"` → **`0x50BBF20120725`** (correct handshake sequence)
3. **Improved handshake**: Implemented proper 7-step protocol with:
   - Byte-by-byte magic send (10ms delays)
   - Hardware flow control (RTS/CTS)
   - Proper ACK/NAK handling

---

## Current Issue: Radio Not Responding

Even with corrections, the radio **isn't sending ACK** to the handshake. This means the radio is likely **not in bootloader/programming mode**.

### Why This Happens

The UV-5RM communicates in **programming mode** only. In normal mode, it ignores these commands.

### How CHIRP Enters Programming Mode

CHIRP can connect because it uses a special procedure:
1. Sends initial handshake bytes to wake the radio
2. Waits for response from bootloader
3. **The bootloader must be active** when you plug in the USB cable

### Solutions to Try:

#### **Option 1: Check if Your Radio Supports Programming Mode** (MOST LIKELY)
1. Open **CHIRP**
2. Go to **Radio → Clone from Radio**
3. If CHIRP says "Connected!" or asks for a filename, your radio **does** support programming mode
4. If CHIRP times out or says "No radio found", your radio's **bootloader may be disabled** or hardware incompatible

#### **Option 2: Verify USB Connection**
- Try a **different USB cable** (prefer short, quality cables)
- Try **different USB ports** on your computer
- Close other serial apps (CHIRP, Arduino IDE, miniterm, etc)
- On macOS: Open Terminal and run:
  ```bash
  ls -la /dev/cu.* /dev/tty.*
  ```
  You should see `/dev/cu.Plser` or `/dev/cu.usbserial-*`

#### **Option 3: Check USB Driver**
On macOS with Prolific PL2303 cables:
- Install the latest driver from: https://www.prolific.com.tw/US/ShowProduct.aspx?p_id=229
- Or use a Silicon Labs CP2102 cable instead (more reliable)

#### **Option 4: Hardware Issue**
- The radio's **bootloader may be corrupted** (brick situation)
- Some UV-5RM versions use **different bootloader protocols** not yet reverse-engineered
- Try using **CHIRP exclusively** for firmware/logo updates (it works!)

---

## How to Confirm It's Fixed (Once Radio Responds)

After the radio starts responding:

1. Run the test script:
   ```bash
   cd /Users/xoni/Documents/GitHub/LogoFlasher
   ./venv/bin/python test_connection.py
   ```

2. You should see:
   ```
   ✓ SUCCESS! Radio ID: [radio model info]
   Connection verified - radio is responding correctly!
   ```

3. Then use the **Streamlit app** to flash logos:
   ```bash
   ./venv/bin/streamlit run src/baofeng_logo_flasher/streamlit_ui.py
   ```

---

## Next Steps

**Before continuing, confirm:**
- ✓ Radio is powered on
- ✓ USB cable is securely connected
- ✓ No other apps are using the serial port
- ✓ CHIRP can successfully "Clone from Radio" (proves bootloader works)

If CHIRP works but our app doesn't, there may be **one more initialization step** needed. We can reverse-engineer what CHIRP does and add it to our code.

Would you like me to:
1. Compare what CHIRP sends vs what we send?
2. Add debugging logs to capture the serial traffic?
3. Switch to using CHIRP's exact protocol implementation?

---

## Technical Details

- **Protocol Source**: Baofeng-UV-5RM-5RH-RE GitHub repo reverse engineering docs
- **Baud Rate**: 9600 bps (not 38400)
- **Magic Bytes**: Various sequences for different firmware versions
- **Port Timeout**: 1.5-3.0 seconds

See: `inputs/uv5rm_protocol_summary.md` for full protocol spec
