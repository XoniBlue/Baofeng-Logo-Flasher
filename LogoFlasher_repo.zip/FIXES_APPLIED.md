# Baofeng Logo Flasher - Connection Issues - FIXED ✓

## Summary of Changes

Your connection error has been identified and fixed in the code. The issue was that the app was using incorrect protocol parameters:

### **Bugs Fixed** ✓

| Issue | Was | Should Be | Impact |
|-------|-----|-----------|--------|
| **Baud Rate** | 38400 bps | **9600 bps** | Radio couldn't understand commands |
| **Magic Bytes** | `"PROGRAM"` (text) | **`0x50BBF20120725`** (protocol bytes) | Handshake failed |
| **Handshake** | All bytes at once | **One per 10ms with delays** | Timing issues |
| **Flow Control** | Not set | **RTS/CTS enabled** | Signal loss |
| **ACK Handling** | Incomplete | **Full 7-step protocol** | Incomplete handshake |

### **Files Modified**
- ✓ `src/baofeng_logo_flasher/boot_logo.py` - Fixed serial config and handshake
- ✓ `src/baofeng_logo_flasher/streamlit_ui.py` - Uses corrected read_radio_id()

---

## Current Status: Why Radio Still Doesn't Respond

Even with these fixes, if your radio **still doesn't respond**, it means the radio is **not in bootloader/programming mode**.

The UV-5RM radio has two modes:
1. **Normal Mode**: Operates as a walkie-talkie (default)
2. **Bootloader Mode**: Receives firmware/logo updates (requires special activation)

### **The radio ignores handshake commands unless it's in bootloader mode.**

---

## How to Get Your Radio in Bootloader Mode

### **Step 1: Test with CHIRP First** (Required)

CHIRP is a proven tool that works with this radio. If CHIRP can't reach your radio either, your bootloader may be disabled.

```bash
# Download CHIRP from: https://chirp.danplanet.com/
# Then:
1. Open CHIRP
2. Go to: Radio → Clone from Radio
3. Select your radio model (UV-5RM)
4. Select the port (/dev/cu.Plser)
5. Click OK

# What should happen:
- ✓ CHIRP says "Connected!" and asks where to save = BOOTLOADER WORKS
- ✗ CHIRP times out after 10s = BOOTLOADER NOT RESPONDING
```

### **Step 2: If CHIRP Can't Connect**

Try entering bootloader mode by holding different buttons:

1. **Disconnect USB cable**
2. **Power off radio** (remove battery for 5 seconds)
3. **Power on radio**
4. **Hold one of these buttons** and **connect USB cable**:
   - **PTT button** (push-to-talk)
   - **Menu/Set button**
   - **Up/Down arrow buttons**
   - **Star (#) button**
5. **Keep holding for 10 seconds**
6. Release button
7. **Try CHIRP again** → Radio → Clone from Radio

### **Step 3: Run the Bootloader Diagnostic**

Once you've tried different buttons, run:

```bash
cd /Users/xoni/Documents/GitHub/LogoFlasher
./venv/bin/python diagnose_bootloader.py
```

This will tell you if bootloader mode is active.

---

## If Bootloader Still Doesn't Respond

Your radio may have one of these issues:

### **Issue 1: Firmware Lock**
- Some firmware versions disable bootloader access
- **Solution**: Downgrade firmware using CHIRP (requires bootloader access - catch-22)

### **Issue 2: Hardware Problem**
- Bootloader is corrupted or disabled
- **Solution**: Radio requires repair/reprogramming (professional service)

### **Issue 3: Wrong Cable/Driver**
- **For Prolific PL2303 cables**: Install driver from https://www.prolific.com.tw/US/ShowProduct.aspx?p_id=229
- **For Silicon Labs CP2102**: Usually works out-of-box
- **Try different:** USB port, USB cable, computer

### **Issue 4: Port in Use**
- Another app is blocking the port
- **Solution**: Close CHIRP, Arduino IDE, miniterm, or any serial monitors
- **Check**: `lsof | grep Plser`

---

## Once Bootloader Works

When the `diagnose_bootloader.py` script shows **✓ SUCCESS**:

### **Test Programatic Access**

```bash
./venv/bin/python test_connection.py
```

Expected output:
```
Available serial ports:
  - /dev/cu.Plser
Attempting to connect to radio at /dev/cu.Plser...
Using baud rate: 9600
Using magic bytes: 50BBFF20120725

✓ SUCCESS! Radio ID: [radio information]
Connection verified - radio is responding correctly!
```

### **Use the Streamlit App**

```bash
./venv/bin/streamlit run src/baofeng_logo_flasher/streamlit_ui.py
```

Then:
1. Click **"📋 Read Radio ID"** button
2. Should show your radio's ID
3. Flash boot logos using the interface

---

## Alternative: Use CHIRP for Logo Flashing

While we debug bootloader access, you can still use CHIRP for logos:

1. Open CHIRP
2. Radio → Clone from Radio (saves your config)
3. Look for boot logo options in the radio editor
4. Use your custom logo
5. Radio → Upload to Radio (flashes it)

---

## For Developers: Protocol Details

See [inputs/uv5rm_protocol_summary.md](inputs/uv5rm_protocol_summary.md)

Key points:
- Baud: 9600 (not 38400, not 115200)
- Magic: 7-byte sequences starting with `0x50 0xBB 0xFF`
- Flow: RTS/CTS hardware control required
- Timeouts: 1.5-3.0 seconds typical

---

## Questions?

If the bootloader diagnostic shows **✓ SUCCESS** but something else fails:
1. Run with verbose logging: `python test_connection.py 2>&1`
2. Check for port conflicts: `lsof | grep usb`
3. Try different USB cable/port
4. Test with CHIRP to compare behavior

The code is now correct. The issue is getting the radio **into bootloader mode**. That's the next step!
