"""
Boot logo read/write support for Baofeng radios.

UV-5RM/UV-5RH HARDWARE ARCHITECTURE (from reverse engineering):
================================================================
Based on: https://github.com/amoxu/Baofeng-UV-5RM-5RH-RE

Components:
- MCU: AT32F421C8T7 (64KB internal flash, 16KB SRAM)
- External Flash: XMC 25QH16CJIG - 16Mbit (2MB) SPI flash
- RF: BK4819

Memory Layout:
- MCU Internal Flash:
  - 0x08000000-0x08000FFF: Bootloader (4KB, protected)
  - 0x08001000-0x0800FFFF: Firmware (60KB)
- External SPI Flash (2MB):
  - Boot logo, audio prompts, and other assets

WHY DIRECT SERIAL FLASHING DOESN'T WORK:
=========================================
The clone protocol (CHIRP/UV17Pro) only accesses the MCU's internal memory.
Boot logos are stored on the EXTERNAL SPI flash chip, which requires:
1. Firmware-level access (the running firmware reads/writes SPI flash)
2. Or direct SPI programming via hardware

The clone protocol can only read/write channel data and settings from
the MCU memory range, NOT the external 2MB SPI flash where logos reside.

ALTERNATIVE APPROACHES:
=======================
1. Patch clone image file (if logo is cached in clone area - unlikely for UV-5RM)
2. Modify firmware and re-flash via bootloader (complex, risky)
3. Direct SPI flash programming via SWD/hardware (requires opening radio)

This module still attempts the clone protocol write for compatibility with
older radios that may store logos in MCU memory, but UV-5RM will reject writes.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Callable
import logging
import struct

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    serial = None
    
from PIL import Image

from .bmp_utils import (
    BmpInfo,
    validate_bmp_bytes,
    convert_image_to_bmp_bytes,
    parse_bmp_header,
)
from .protocol import UV5RMProtocol, RadioBlockError, RadioTransportError

logger = logging.getLogger(__name__)

BOOT_LOGO_SIZE = (160, 128)


@dataclass(frozen=True)
class LogoRegion:
    start: int
    length: int
    block_size: int


@dataclass(frozen=True)
class BootLogoModelConfig:
    name: str
    logo_region: Optional[LogoRegion]
    scan_ranges: List[Tuple[int, int]]


MODEL_CONFIGS: Dict[str, BootLogoModelConfig] = {
    "UV-5RH Pro": BootLogoModelConfig(
        name="UV-5RH Pro",
        logo_region=None,
        scan_ranges=[],
    ),
    "UV-17R": BootLogoModelConfig(
        name="UV-17R",
        logo_region=None,
        scan_ranges=[],
    ),
    "UV-17R Pro": BootLogoModelConfig(
        name="UV-17R Pro",
        logo_region=None,
        scan_ranges=[],
    ),
}

# Serial flashing protocol configs for direct boot logo flashing
# UV-5RM uses the UV17Pro driver protocol from CHIRP, NOT the UV5R protocol!
#
# WARNING: Boot logo addresses are EXPERIMENTAL and may not work on all firmware!
# The actual boot logo location varies by firmware version and may require discovery
# via the clone image scan method. The protocol used here accesses the clone memory,
# but boot logos may be stored in separate flash regions not accessible this way.
SERIAL_FLASH_CONFIGS: Dict[str, Dict] = {
    "UV-5RM": {
        "size": (160, 128),
        "color_mode": "RGB",
        "encrypt": True,
        "start_addr": 0x1000,  # EXPERIMENTAL - may need discovery for your firmware
        # UV-5RM uses UV17Pro protocol per CHIRP baofeng_uv17Pro.py
        "magic": b"PROGRAMBFNORMALU",  # 16-byte ident string for UV17L/5RM
        "block_size": 64,
        "key": b"\xAB\xCD\xEF",
        "baudrate": 115200,  # UV17Pro protocol uses 115200, NOT 9600!
        "timeout": 3.0,
        # Additional magics sent after ident handshake (from UV17Pro._magics)
        "post_ident_magics": [
            (b"\x46", 16),    # Returns 16 bytes
            (b"\x4d", 15),    # Returns 15 bytes  
            (b"\x53\x45\x4E\x44\x21\x05\x0D\x01\x01\x01\x04\x11\x08\x05"
             b"\x0D\x0D\x01\x11\x0F\x09\x12\x09\x10\x04\x00", 1),
        ],
        "fingerprint": b"\x06",  # Expected response to ident
    },
    "DM-32UV": {
        "size": (240, 320),
        "color_mode": "RGB",
        "encrypt": False,
        "start_addr": 0x2000,
        "magic": b"\x50\xBB\xFF\x20\x12\x07\x25",  # Default to UV5R
        "block_size": 64,
        "baudrate": 9600,  # Standard UV5R protocol
        "timeout": 3.0,
    },
}


class BootLogoError(Exception):
    """Errors raised by boot logo operations."""


def baofeng_encrypt(data: bytes, key: bytes = b"\xAB\xCD\xEF") -> bytes:
    """Encrypt data using Baofeng algorithm (XOR + rotate)."""
    encrypted = bytearray()
    key_len = len(key)
    for i, byte in enumerate(data):
        enc_byte = byte ^ key[i % key_len]
        shift = i % 8
        enc_byte = ((enc_byte << shift) & 0xFF) | (enc_byte >> (8 - shift))
        encrypted.append(enc_byte)
    return bytes(encrypted)


def convert_bmp_to_raw(bmp_path: str, config: Dict) -> bytes:
    """Convert BMP file to raw format suitable for the target radio model."""
    size: Tuple[int, int] = config["size"]
    color_mode: str = config["color_mode"]
    encrypt: bool = config.get("encrypt", False)
    key: bytes = config.get("key", b"\xAB\xCD\xEF")

    img = Image.open(bmp_path)
    if img.format != "BMP":
        raise BootLogoError("Input must be a BMP file")

    img = img.resize(size)
    img = img.transpose(Image.FLIP_TOP_BOTTOM)  # BMP bottom-up -> radio format

    if color_mode == "RGB332":
        img = img.convert("RGB")
        raw = bytearray()
        for r, g, b in img.getdata():
            packed = ((r >> 5) << 5) | ((g >> 5) << 2) | (b >> 6)
            raw.append(struct.pack("B", packed)[0])
        raw_bytes = bytes(raw)
    else:
        img = img.convert(color_mode)
        raw_bytes = img.tobytes()

    if encrypt:
        raw_bytes = baofeng_encrypt(raw_bytes, key=key)

    return raw_bytes


def list_serial_ports() -> List[str]:
    """List available serial ports."""
    if not serial:
        return []
    return [p.device for p in serial.tools.list_ports.comports()]


def read_radio_id(
    port: str,
    magic: bytes = None,
    baudrate: int = 115200,  # Default to UV17Pro protocol
    timeout: float = 1.5,
    protocol: str = "uv17pro",  # "uv17pro" or "uv5r"
    post_ident_magics: list = None,
    fingerprint: bytes = b"\x06",
) -> str:
    """
    Connect to radio and read its ID using CHIRP-compatible handshake protocol.
    
    For UV-5RM, uses UV17Pro protocol from chirp/drivers/baofeng_uv17Pro.py.
    For legacy UV-5R variants, uses uv5r.py protocol.
    """
    if not serial:
        raise BootLogoError("PySerial not installed")
    
    import time
    
    if protocol == "uv17pro":
        # UV17Pro protocol (UV-5RM, UV-17, etc.)
        # Default magic for UV-5RM/UV17L
        if magic is None:
            magic = b"PROGRAMBFNORMALU"
        
        return _do_ident_uv17pro(port, magic, baudrate, timeout, 
                                  post_ident_magics, fingerprint)
    else:
        # Legacy UV5R protocol (7-byte magic sequences)
        MAGIC_SEQUENCES = [
            b"\x50\xBB\xFF\x20\x12\x07\x25",  # UV5R BFB291+
            b"\x50\xBB\xFF\x01\x25\x98\x4D",  # UV5R Original
            b"\x50\xBB\xFF\x20\x13\x01\x05",  # UV82
            b"\x50\xBB\xFF\x20\x12\x08\x23",  # UV6
            b"\x50\xBB\xFF\x13\xA1\x11\xDD",  # F11
            b"\x50\xBB\xFF\x20\x14\x04\x13",  # A58
            b"\x50\xBB\xFF\x20\x12\x06\x25",  # UV5G
            b"\x50\xBB\xFF\x12\x03\x98\x4D",  # UV6 Original
        ]
        
        if magic is not None:
            sequences_to_try = [magic]
        else:
            sequences_to_try = MAGIC_SEQUENCES
        
        last_error = None
        
        for magic_seq in sequences_to_try:
            try:
                result = _do_ident_uv5r(port, magic_seq, 9600, timeout)
                return result
            except BootLogoError as e:
                last_error = e
                logger.debug(f"Magic {magic_seq.hex()} failed: {e}")
                time.sleep(0.5)
        
        if last_error:
            raise last_error
        raise BootLogoError("Radio did not respond to any known magic sequences")


def _do_ident_uv17pro(port: str, magic: bytes, baudrate: int, timeout: float,
                       post_ident_magics: list = None, fingerprint: bytes = b"\x06") -> str:
    """
    Perform identification handshake using UV17Pro protocol.
    Based on chirp/drivers/baofeng_uv17Pro.py _do_ident() function.
    """
    import time
    
    # UV17Pro uses NO hardware flow control, just like chirp/baofeng_common.py
    ser = serial.Serial(
        port=port,
        baudrate=baudrate,
        bytesize=8,
        parity='N',
        stopbits=1,
        timeout=timeout,
        write_timeout=timeout,
    )
    
    try:
        # Clean buffer first (CHIRP style)
        ser.timeout = 0.005
        junk = ser.read(256)
        if junk:
            logger.debug(f"Cleared {len(junk)} bytes of junk from buffer")
        ser.timeout = timeout
        
        logger.debug(f"Connected to {port} at {baudrate} baud (UV17Pro protocol)")
        logger.debug(f"Sending ident magic: {magic!r}")
        
        # Send the full magic string at once (UV17Pro style)
        ser.write(magic)
        
        # Read expected fingerprint response
        fingerprint_len = len(fingerprint)
        response = ser.read(fingerprint_len)
        
        if not response:
            raise BootLogoError(
                f"No response to ident magic. Is radio powered on and connected?"
            )
        
        if not response.startswith(fingerprint):
            logger.debug(f"Expected fingerprint {fingerprint.hex()}, got {response.hex()}")
            raise BootLogoError(
                f"Unexpected response: {response.hex()} (expected {fingerprint.hex()})"
            )
        
        logger.debug(f"Received fingerprint: {response.hex().upper()}")
        
        # Send additional magic commands (UV17Pro._magics)
        # The second response (0x4d) contains the model name
        model_name = None
        if post_ident_magics:
            for i, (cmd, resp_len) in enumerate(post_ident_magics):
                logger.debug(f"Sending post-ident magic: {cmd.hex()[:20]}...")
                ser.write(cmd)
                resp = ser.read(resp_len)
                logger.debug(f"Got response: {resp.hex() if resp else 'none'}")
                # Second magic response (0x4D) contains the model name in ASCII
                if i == 1 and resp:
                    try:
                        model_name = resp.decode('ascii', errors='ignore').strip()
                    except:
                        pass
        
        logger.debug("UV17Pro handshake complete")
        
        # Return model info if available, otherwise just fingerprint
        if model_name:
            return f"UV17Pro ({model_name})"
        return f"UV17Pro-{response.hex().upper()}"
    finally:
        ser.close()


def _do_ident_uv5r(port: str, magic: bytes, baudrate: int, timeout: float) -> str:
    """
    Perform identification handshake using legacy UV5R protocol.
    Based on chirp/drivers/uv5r.py _do_ident() function.
    """
    import time
    
    # Match CHIRP's serial config exactly - NO rtscts
    ser = serial.Serial(
        port=port,
        baudrate=baudrate,
        bytesize=8,
        parity='N',
        stopbits=1,
        timeout=timeout,
        write_timeout=timeout,
    )
    
    try:
        # Clean buffer first (CHIRP style)
        ser.timeout = 0.005
        junk = ser.read(256)
        if junk:
            logger.debug(f"Cleared {len(junk)} bytes of junk from buffer")
        ser.timeout = timeout
        
        logger.debug(f"Connected to {port} at {baudrate} baud (UV5R protocol)")
        logger.debug(f"Sending magic: {magic.hex().upper()}")
        
        # Send magic bytes one at a time with 10ms delay (CHIRP uv5r.py style)
        for byte in magic:
            ser.write(bytes([byte]))
            time.sleep(0.01)
        
        # Read ACK
        ack1 = ser.read(1)
        if ack1 != b'\x06':
            if ack1:
                logger.debug(f"Got: {ack1.hex()}")
            raise BootLogoError(
                f"No ACK after magic (got {ack1.hex() if ack1 else 'nothing'}). "
                f"Is radio powered on and connected?"
            )
        
        logger.debug("Received ACK")
        
        # Send 0x02 command
        ser.write(b'\x02')
        
        # Read identification (until 0xDD or max 12 bytes)
        ident_response = b""
        for i in range(12):
            byte = ser.read(1)
            if not byte:
                break
            ident_response += byte
            if byte == b'\xDD':
                break
        
        logger.debug(f"Received ident: {ident_response.hex().upper()}")
        
        # Validate response
        if len(ident_response) not in [8, 12]:
            raise BootLogoError(f"Invalid ident length: {len(ident_response)}")
        
        if not ident_response.startswith(b'\xAA') or not ident_response.endswith(b'\xDD'):
            raise BootLogoError(f"Invalid ident format: {ident_response.hex()}")
        
        # Send confirmation ACK
        ser.write(b'\x06')
        
        # Read second ACK
        ack2 = ser.read(1)
        if ack2 != b'\x06':
            raise BootLogoError(f"Radio refused clone (got {ack2.hex() if ack2 else 'nothing'})")
        
        logger.debug("Handshake complete")
        
        # Normalize 12-byte ident to 8 bytes (filter 0x01 bytes for UV-6)
        if len(ident_response) == 12:
            ident = bytes([b for b in ident_response if b != 0x01])[:8]
        else:
            ident = ident_response
        
        # Extract readable ID
        radio_id = ident[1:-1].decode(errors="ignore").strip("\x00")
        if not radio_id:
            radio_id = ident.hex().upper()
        
        return radio_id
    finally:
        ser.close()


def flash_logo(
    port: str,
    bmp_path: str,
    config: Dict,
    simulate: bool = False,
    progress_cb: Optional[Callable[[int, int], None]] = None,
) -> str:
    """Flash boot logo to radio via serial connection."""
    if not serial and not simulate:
        raise BootLogoError("PySerial not installed")
    
    raw_data = convert_bmp_to_raw(bmp_path, config)
    block_size = int(config.get("block_size", 64))
    start_addr = int(config["start_addr"])
    magic = config["magic"]
    baudrate = int(config.get("baudrate", 115200))
    timeout = float(config.get("timeout", 3.0))
    
    # Check if this is UV17Pro protocol (16-byte magic) or legacy UV5R (7-byte magic)
    is_uv17pro = len(magic) == 16
    post_ident_magics = config.get("post_ident_magics", [])
    fingerprint = config.get("fingerprint", b"\x06")

    if simulate:
        return f"Simulation: {len(raw_data)} bytes to 0x{start_addr:04X} via {port}"

    ser = serial.Serial(port, baudrate, timeout=timeout)
    try:
        import time
        
        # Clear buffers and initialize
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        time.sleep(0.1)
        
        radio_id = "UNKNOWN"
        
        if is_uv17pro:
            # === UV17Pro Protocol (UV-5RM, UV-17, etc.) ===
            # Based on chirp/drivers/baofeng_uv17Pro.py
            logger.debug(f"Flashing to {port}: Using UV17Pro protocol")
            
            # Step 1: Send full magic at once (NOT byte-by-byte)
            ser.write(magic)
            ser.flush()
            
            # Step 2: Read fingerprint response
            response = ser.read(len(fingerprint))
            if not response:
                raise BootLogoError(
                    f"No response from radio. Is it powered on and connected to {port}?"
                )
            if response != fingerprint:
                raise BootLogoError(
                    f"Unexpected response: {response.hex()} (expected {fingerprint.hex()})"
                )
            logger.debug(f"Received fingerprint: {response.hex().upper()}")
            
            # Step 3: Send post-ident magics (REQUIRED for UV17Pro before read/write!)
            for i, (cmd, resp_len) in enumerate(post_ident_magics):
                logger.debug(f"Sending post-ident magic {i+1}: {cmd.hex()[:20]}...")
                ser.write(cmd)
                ser.flush()
                resp = ser.read(resp_len)
                logger.debug(f"Got response: {resp.hex() if resp else 'none'}")
                # Second magic response (0x4D) contains model name
                if i == 1 and resp:
                    try:
                        radio_id = resp.decode('ascii', errors='ignore').strip()
                    except:
                        pass
            
            if not radio_id or radio_id == "UNKNOWN":
                radio_id = f"UV17Pro-{response.hex().upper()}"
            
            logger.debug("UV17Pro handshake complete")
        else:
            # === Legacy UV5R Protocol ===
            logger.debug(f"Flashing to {port}: Using legacy UV5R protocol")
            
            # Step 1: Send magic bytes one at a time with 10ms delay
            for byte in magic:
                ser.write(bytes([byte]))
                ser.flush()
                time.sleep(0.01)
            
            # Step 2: Receive ACK
            ack = ser.read(1)
            if ack != b"\x06":
                raise BootLogoError(
                    f"No ACK from radio (got {ack.hex() if ack else 'nothing'}). Is it powered on?"
                )
            
            # Step 3: Send mode request
            ser.write(b"\x02")
            ser.flush()
            
            # Step 4: Receive identification
            ident_response = b""
            for i in range(12):
                byte = ser.read(1)
                if not byte:
                    break
                ident_response += byte
                if byte == b'\xDD':
                    break
            
            if ident_response:
                radio_id = ident_response[1:-1].decode(errors="ignore").strip("\x00")
                if not radio_id:
                    radio_id = ident_response.hex().upper()
            
            # Step 5: Send confirmation
            ser.write(b"\x06")
            ser.flush()
            
            # Step 6: Receive second ACK
            ack2 = ser.read(1)
            
            logger.debug("UV5R handshake complete")
        
        logger.debug(f"Handshake complete. Radio ID: {radio_id}")
        
        # === Write logo blocks ===
        addr = start_addr
        total = len(raw_data)
        written = 0

        for i in range(0, total, block_size):
            block = raw_data[i : i + block_size]
            block_len = len(block)
            
            # Write protocol: 'X' (0x58) + addr (2 bytes BE) + length (1 byte) + data
            cmd = struct.pack(">BHB", ord('X'), addr, block_len) + block
            ser.write(cmd)
            ser.flush()
            time.sleep(0.05)

            ack = ser.read(1)
            if not ack or ack != b"\x06":
                ack_val = ack.hex() if ack else 'nothing'
                # Decode common response codes
                if ack == b'R':  # 0x52 = 'R'
                    hint = "Radio returned 'R' (0x52) - this typically means the address is read-only or not accessible."
                elif ack == b'E':  # 0x45 = 'E'
                    hint = "Radio returned 'E' (0x45) - command error or invalid address."
                elif ack == b'\x15':  # NAK
                    hint = "Radio returned NAK (0x15) - command not acknowledged."
                else:
                    hint = f"Unexpected response: 0x{ack_val}"
                
                raise BootLogoError(
                    f"Write failed at 0x{addr:04X} (got {ack_val}). {hint} "
                    f"The boot logo address 0x{start_addr:04X} may not be correct for your firmware."
                )

            addr += block_len
            written += block_len

            if progress_cb:
                progress_cb(written, total)

        ser.write(b"E")
        ser.flush()
        return f"Logo flashed! Radio: {radio_id}. Power cycle the radio."
    finally:
        ser.close()


def baofeng_decrypt(data: bytes, key: bytes = b"\xAB\xCD\xEF") -> bytes:
    """Decrypt data using Baofeng algorithm (reverse of encrypt: rotate back + XOR)."""
    decrypted = bytearray()
    key_len = len(key)
    for i, byte in enumerate(data):
        shift = i % 8
        # Reverse the rotation first
        dec_byte = ((byte >> shift) | ((byte << (8 - shift)) & 0xFF)) & 0xFF
        # Then XOR with key
        dec_byte = dec_byte ^ key[i % key_len]
        decrypted.append(dec_byte)
    return bytes(decrypted)


def convert_raw_to_bmp(raw_data: bytes, config: Dict) -> bytes:
    """Convert raw radio format to BMP file bytes."""
    size: Tuple[int, int] = config["size"]
    color_mode: str = config.get("color_mode", "RGB")
    encrypt: bool = config.get("encrypt", False)
    key: bytes = config.get("key", b"\xAB\xCD\xEF")

    # Decrypt if needed
    if encrypt:
        raw_data = baofeng_decrypt(raw_data, key=key)

    # Create image from raw data
    if color_mode == "RGB332":
        # Expand RGB332 to RGB
        pixels = []
        for byte in raw_data:
            r = ((byte >> 5) & 0x07) * 36  # 3 bits to 8 bits
            g = ((byte >> 2) & 0x07) * 36  # 3 bits to 8 bits
            b = (byte & 0x03) * 85          # 2 bits to 8 bits
            pixels.append((r, g, b))
        img = Image.new("RGB", size)
        img.putdata(pixels)
    else:
        # Assume RGB (3 bytes per pixel)
        expected_size = size[0] * size[1] * 3
        if len(raw_data) < expected_size:
            # Pad with zeros if needed
            raw_data = raw_data + b'\x00' * (expected_size - len(raw_data))
        img = Image.frombytes(color_mode, size, raw_data[:expected_size])

    # Flip back (radio format is bottom-up like BMP)
    img = img.transpose(Image.FLIP_TOP_BOTTOM)

    # Convert to BMP bytes
    import io
    buffer = io.BytesIO()
    img.save(buffer, format="BMP")
    return buffer.getvalue()


def read_logo(
    port: str,
    config: Dict,
    simulate: bool = False,
    progress_cb: Optional[Callable[[int, int], None]] = None,
) -> Tuple[bytes, str]:
    """
    Read boot logo from radio via serial connection.
    
    Uses the same handshake protocol as flash_logo to ensure compatibility.
    
    Returns:
        Tuple of (raw_bytes, radio_id)
    """
    if not serial and not simulate:
        raise BootLogoError("PySerial not installed")

    size = config["size"]
    # Calculate expected logo size (RGB = 3 bytes per pixel)
    color_mode = config.get("color_mode", "RGB")
    if color_mode == "RGB332":
        total_bytes = size[0] * size[1]  # 1 byte per pixel
    else:
        total_bytes = size[0] * size[1] * 3  # 3 bytes per pixel

    block_size = int(config.get("block_size", 64))
    start_addr = int(config["start_addr"])
    magic = config["magic"]
    baudrate = int(config.get("baudrate", 115200))
    timeout = float(config.get("timeout", 3.0))

    if simulate:
        # Return dummy data for simulation
        dummy_data = bytes([0x00] * total_bytes)
        return dummy_data, "SIMULATED"

    ser = serial.Serial(port, baudrate, timeout=timeout)
    try:
        import time
        
        # Clear buffers and initialize
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        time.sleep(0.1)
        
        # Use EXACTLY the same handshake as flash_logo (which works)
        # Send magic bytes one at a time with 10ms delay
        logger.debug(f"Reading from {port}: Sending magic bytes")
        for byte in magic:
            ser.write(bytes([byte]))
            ser.flush()
            time.sleep(0.01)
        
        ack = ser.read(1)
        if ack != b"\x06":
            raise BootLogoError(
                f"No response from radio (got {ack.hex() if ack else 'nothing'}). Is it powered on at {port}?"
            )

        # Send mode request and receive identification
        ser.write(b"\x02")
        ser.flush()
        
        ident_response = b""
        for i in range(12):
            byte = ser.read(1)
            if not byte:
                break
            ident_response += byte
            if byte == b'\xDD':
                break
        
        radio_id = ident_response[1:-1].decode(errors="ignore").strip("\x00") if ident_response else "UNKNOWN"
        if not radio_id:
            radio_id = ident_response.hex().upper() if ident_response else "UNKNOWN"

        # Send confirmation and receive second ACK
        ser.write(b"\x06")
        ser.flush()
        ack2 = ser.read(1)
        
        logger.debug(f"Handshake complete. Radio ID: {radio_id}")
        
        # === Read logo blocks ===
        # Use 'S' command for read: S + addr(2) + size(1)
        # Response: X + addr(2) + size(1) + data
        data = bytearray()
        addr = start_addr
        read_bytes = 0
        
        for i in range(0, total_bytes, block_size):
            remaining = min(block_size, total_bytes - i)
            
            # Send read command: 'S' + addr (2 bytes BE) + size (1 byte)
            cmd = struct.pack(">BHB", ord('S'), addr, remaining)
            ser.write(cmd)
            ser.flush()
            time.sleep(0.05)
            
            # Read response header: 'X' + addr (2 bytes) + size (1 byte)
            hdr = ser.read(4)
            if len(hdr) != 4:
                # If we got partial data, read more with longer timeout
                if len(hdr) > 0:
                    ser.timeout = timeout * 2
                    more = ser.read(4 - len(hdr))
                    hdr += more
                    ser.timeout = timeout
                
                if len(hdr) != 4:
                    raise BootLogoError(
                        f"Incomplete response at 0x{addr:04X} (got {len(hdr)} bytes: {hdr.hex() if hdr else 'none'}). "
                        f"Radio may not support logo read at this address."
                    )
            
            resp_cmd, resp_addr, resp_size = struct.unpack(">BHB", hdr)
            
            if resp_cmd != ord('X'):
                raise BootLogoError(
                    f"Invalid response command at 0x{addr:04X}: got 0x{resp_cmd:02X}, expected 0x{ord('X'):02X}. "
                    f"Full header: {hdr.hex()}"
                )
            
            # Read data block
            block = ser.read(resp_size)
            if len(block) != resp_size:
                raise BootLogoError(
                    f"Incomplete block at 0x{addr:04X}: expected {resp_size}, got {len(block)}"
                )
            
            data.extend(block)
            
            # Send ACK
            ser.write(b"\x06")
            ser.flush()
            time.sleep(0.02)
            
            addr += remaining
            read_bytes += remaining
            
            if progress_cb:
                progress_cb(read_bytes, total_bytes)

        # End session
        ser.write(b"E")
        ser.flush()
        
        return bytes(data), radio_id
    finally:
        ser.close()


class BootLogoService:
    def __init__(self, protocol: UV5RMProtocol):
        self.protocol = protocol

    def resolve_model_config(self, model_name: str) -> BootLogoModelConfig:
        if model_name in MODEL_CONFIGS:
            return MODEL_CONFIGS[model_name]
        raise BootLogoError(f"Unsupported model: {model_name}")

    def resolve_logo_region(
        self,
        model_config: BootLogoModelConfig,
        logo_start: Optional[int] = None,
        logo_length: Optional[int] = None,
        block_size: Optional[int] = None,
    ) -> LogoRegion:
        if logo_start is not None and logo_length is not None:
            region_block = block_size or 0x40
            return LogoRegion(start=logo_start, length=logo_length, block_size=region_block)

        if model_config.logo_region is None:
            raise BootLogoError(
                "Logo region not configured for this model. "
                "Provide --logo-start/--logo-length or run discovery."
            )

        if block_size is not None:
            return LogoRegion(
                start=model_config.logo_region.start,
                length=model_config.logo_region.length,
                block_size=block_size,
            )

        return model_config.logo_region

    def read_logo(self, region: LogoRegion) -> bytes:
        self._validate_region(region)
        data = bytearray()
        end = region.start + region.length

        for addr in range(region.start, end, region.block_size):
            size = min(region.block_size, end - addr)
            block = self.protocol.read_block(addr, size)
            data.extend(block)

        return bytes(data)

    def write_logo(self, region: LogoRegion, data: bytes) -> None:
        self._validate_region(region)

        if len(data) != region.length:
            raise BootLogoError(
                f"Logo data length {len(data)} does not match region length {region.length}"
            )

        end = region.start + region.length
        offset = 0

        for addr in range(region.start, end, region.block_size):
            size = min(region.block_size, end - addr)
            chunk = data[offset:offset + size]
            self.protocol.write_block(addr, chunk)
            offset += size

    def validate_logo_bytes(self, data: bytes) -> BmpInfo:
        return validate_bmp_bytes(data, BOOT_LOGO_SIZE)

    def prepare_logo_bytes(self, image_path: str) -> bytes:
        try:
            with open(image_path, "rb") as handle:
                raw = handle.read()
            self.validate_logo_bytes(raw)
            return raw
        except Exception:
            return convert_image_to_bmp_bytes(image_path, BOOT_LOGO_SIZE)

    def discover_logo_region(
        self,
        scan_ranges: List[Tuple[int, int]],
        block_size: int = 0x40,
        scan_stride: int = 0x10,
    ) -> LogoRegion:
        if not scan_ranges:
            raise BootLogoError("No scan ranges provided for discovery")

        header_size = 54

        for start, end in scan_ranges:
            if end <= start:
                continue
            for addr in range(start, end - header_size, scan_stride):
                try:
                    header = self.protocol.read_block(addr, min(block_size, header_size))
                    if len(header) < 2 or header[0:2] != b"BM":
                        continue

                    if len(header) < header_size:
                        header += self.protocol.read_block(
                            addr + len(header), header_size - len(header)
                        )

                    info = parse_bmp_header(header, allow_partial=True)
                    if (info.width, info.height) != BOOT_LOGO_SIZE:
                        continue
                    length = info.file_size
                    if length <= 0:
                        continue
                    expected_file_size = info.data_offset + info.image_size
                    if length != expected_file_size:
                        continue

                    if addr + length <= end:
                        logger.info(
                            "Discovered BMP at 0x%04X length %d", addr, length
                        )
                        return LogoRegion(start=addr, length=length, block_size=block_size)
                except (RadioBlockError, RadioTransportError, ValueError):
                    continue

        raise BootLogoError("No valid BMP logo found in scan ranges")

    def _validate_region(self, region: LogoRegion) -> None:
        if region.start < 0 or region.length <= 0:
            raise BootLogoError("Invalid logo region")
        if region.block_size <= 0:
            raise BootLogoError("Invalid block size")
        if region.start > 0xFFFF or (region.start + region.length) > 0x10000:
            raise BootLogoError("Logo region out of 16-bit address range")
