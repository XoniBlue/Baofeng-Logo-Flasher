"""
Baofeng Logo Flasher CLI

Complete command-line interface for safe logo flashing with safety verification.
"""

import sys
import logging
import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.logging import RichHandler
from rich.progress import Progress, BarColumn, TextColumn

from baofeng_logo_flasher.protocol import UV5RMTransport, UV5RMProtocol
from baofeng_logo_flasher.boot_logo import (
    BootLogoService,
    BootLogoModelConfig,
    MODEL_CONFIGS,
    SERIAL_FLASH_CONFIGS,
    BOOT_LOGO_SIZE,
    BootLogoError,
)
from baofeng_logo_flasher.bmp_utils import validate_bmp_bytes
from baofeng_logo_flasher.logo_codec import (
    LogoCodec,
    BitmapFormat,
    parse_bitmap_format as _parse_bitmap_format_core,
    BITMAP_FORMAT_ALIASES,
)
from baofeng_logo_flasher.logo_patcher import LogoPatcher
from baofeng_logo_flasher.protocol_verifier import ProtocolVerifier

# CONFIRMATION_STRING must be typed exactly to proceed with radio writes
CONFIRMATION_STRING = "WRITE"

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    handlers=[RichHandler(rich_tracebacks=True)],
)
logger = logging.getLogger("baofeng_logo_flasher")

# Setup Rich console
console = Console()

app = typer.Typer(help="🔧 Baofeng UV-5RM Logo Flasher - Safe image modification")


def print_header(text: str) -> None:
    """Print fancy header."""
    console.print(Panel(text, expand=False, style="bold blue"))


def print_success(text: str) -> None:
    """Print success message."""
    console.print(f"✓ {text}", style="green")


def print_warning(text: str) -> None:
    """Print warning message."""
    console.print(f"⚠️  {text}", style="yellow")


def print_error(text: str) -> None:
    """Print error message."""
    console.print(f"❌ {text}", style="red")


def parse_int(value: Optional[str], label: str) -> Optional[int]:
    """Parse an integer from string (supports decimal and hex)."""
    if value is None:
        return None
    try:
        if value.startswith("0x") or value.startswith("0X"):
            return int(value, 16)
        return int(value)
    except ValueError:
        raise typer.BadParameter(f"Invalid {label}: {value}")


def parse_offset(value: Optional[str]) -> Optional[int]:
    """
    Parse offset value from string, supporting multiple formats.
    
    Accepts:
        - Decimal: "4096"
        - Hex with 0x prefix: "0x1000" or "0X1000"
        - Hex with h suffix: "1000h" or "1000H"
        - None for auto-detection
    
    Returns:
        Parsed integer offset, or None if value is None.
    
    Raises:
        typer.BadParameter: If value cannot be parsed.
    """
    if value is None:
        return None
    
    value = value.strip()
    if not value:
        return None
    
    try:
        # Hex with 0x/0X prefix
        if value.lower().startswith("0x"):
            return int(value, 16)
        # Hex with h/H suffix
        if value.lower().endswith("h"):
            return int(value[:-1], 16)
        # Decimal
        return int(value)
    except ValueError:
        raise typer.BadParameter(
            f"Invalid offset '{value}'. Use decimal (4096), hex (0x1000), or suffix (1000h)."
        )


def parse_bitmap_format(value: str) -> BitmapFormat:
    """
    Parse bitmap format from user-friendly string.
    
    CLI wrapper around logo_codec.parse_bitmap_format that converts
    ValueError to typer.BadParameter for proper CLI error handling.
    
    Accepts canonical enum names and friendly aliases:
        - "ROW_MAJOR_MSB" or "row_msb" or "row-major-msb"
        - "ROW_MAJOR_LSB" or "row_lsb" or "row-major-lsb"
        - "PAGE_MAJOR_MSB" or "page_msb" or "page-major-msb"
        - "PAGE_MAJOR_LSB" or "page_lsb" or "page-major-lsb"
    
    Returns:
        Corresponding BitmapFormat enum value.
    
    Raises:
        typer.BadParameter: If format is not recognized.
    """
    try:
        return _parse_bitmap_format_core(value)
    except ValueError as e:
        raise typer.BadParameter(str(e))


def confirm_write_with_details(
    write_flag: bool,
    model: str,
    target_region: str,
    bytes_length: int,
    offset: Optional[int] = None,
) -> None:
    """
    Require explicit --write flag AND typed confirmation before any radio write.
    
    Displays detected model, target region, and byte length to user.
    Aborts if --write not set or confirmation string doesn't match.
    
    Args:
        write_flag: Value of --write option (must be True to proceed)
        model: Detected radio model name
        target_region: Description of target memory region
        bytes_length: Number of bytes to write
        offset: Optional offset being written to
    """
    if not write_flag:
        console.print()
        print_error("Write operation requires --write flag.")
        console.print("This is a safety measure to prevent accidental writes to your radio.")
        console.print(f"Review the details below and re-run with --write if you wish to proceed.")
        console.print()
        console.print(f"  Model:         {model}")
        console.print(f"  Target:        {target_region}")
        console.print(f"  Bytes:         {bytes_length:,}")
        if offset is not None:
            console.print(f"  Offset:        0x{offset:06X}")
        raise typer.Abort()
    
    # Model/region safety check
    if model == "Unknown" or not model:
        print_error("Cannot write to radio with unknown model. Aborting for safety.")
        raise typer.Abort()
    
    # Display details and require typed confirmation
    console.print()
    console.print(Panel(
        f"[bold yellow]⚠️  WRITE CONFIRMATION REQUIRED[/bold yellow]\n\n"
        f"Model:         {model}\n"
        f"Target:        {target_region}\n"
        f"Bytes:         {bytes_length:,}\n"
        + (f"Offset:        0x{offset:06X}\n" if offset is not None else "") +
        f"\n[bold]Type '{CONFIRMATION_STRING}' to proceed, or anything else to abort:[/bold]",
        title="Radio Write Operation",
        expand=False,
    ))
    
    user_input = typer.prompt("Confirm")
    if user_input.strip().upper() != CONFIRMATION_STRING:
        print_warning("Confirmation failed. Write aborted.")
        raise typer.Abort()
    
    print_success("Confirmation accepted. Proceeding with write...")


def confirm_write(force: bool, prompt: str) -> None:
    """Legacy confirmation helper (simple yes/no). Deprecated for radio writes."""
    if force:
        return
    if not typer.confirm(prompt):
        raise typer.Abort()


@app.command()
def ports() -> None:
    """List available serial ports."""
    print_header("Available Serial Ports")
    
    try:
        import serial.tools.list_ports
        
        ports_list = list(serial.tools.list_ports.comports())
        
        if not ports_list:
            print_warning("No serial ports found")
            return
        
        table = Table(title="Serial Ports")
        table.add_column("Port", style="cyan")
        table.add_column("Device", style="magenta")
        table.add_column("Description", style="green")
        
        for port in ports_list:
            table.add_row(port.device, port.name or "-", port.description or "-")
        
        console.print(table)
    except ImportError:
        print_error("pyserial not installed: pip install pyserial")


@app.command("list-devices")
def list_devices() -> None:
    """Alias for listing available serial ports."""
    ports()


@app.command("list-models")
def list_models() -> None:
    """List supported radio models and their configurations."""
    print_header("Supported Radio Models")
    
    # Serial flash configs (UV-5RM, DM-32UV, etc.)
    if SERIAL_FLASH_CONFIGS:
        table = Table(title="Serial Flash Models")
        table.add_column("Model", style="cyan")
        table.add_column("Logo Size", style="green")
        table.add_column("Color Mode", style="magenta")
        table.add_column("Start Addr", style="yellow")
        table.add_column("Encrypted", style="red")
        table.add_column("Protocol", style="blue")
        
        for name, cfg in sorted(SERIAL_FLASH_CONFIGS.items()):
            size = f"{cfg['size'][0]}x{cfg['size'][1]}"
            color = cfg.get("color_mode", "N/A")
            addr = f"0x{cfg.get('start_addr', 0):04X}"
            encrypted = "Yes" if cfg.get("encrypt", False) else "No"
            # Determine protocol from magic bytes length
            magic_len = len(cfg.get("magic", b""))
            protocol = "UV17Pro" if magic_len == 16 else "UV5R"
            
            table.add_row(name, size, color, addr, encrypted, protocol)
        
        console.print(table)
    
    # Model configs (UV-5RH Pro, UV-17R, etc.)
    if MODEL_CONFIGS:
        console.print()
        table2 = Table(title="Clone-Based Models")
        table2.add_column("Model", style="cyan")
        table2.add_column("Logo Region", style="green")
        table2.add_column("Scan Ranges", style="yellow")
        
        for name, cfg in sorted(MODEL_CONFIGS.items()):
            if cfg.logo_region:
                region = f"0x{cfg.logo_region.start:04X} ({cfg.logo_region.length} bytes)"
            else:
                region = "Unknown (requires discovery)"
            
            if cfg.scan_ranges:
                ranges = ", ".join(f"0x{s:04X}-0x{e:04X}" for s, e in cfg.scan_ranges)
            else:
                ranges = "None defined"
            
            table2.add_row(name, region, ranges)
        
        console.print(table2)
    
    console.print()
    console.print("Use [cyan]show-model-config <model>[/cyan] for detailed configuration.")


@app.command("show-model-config")
def show_model_config(
    model: str = typer.Argument(..., help="Model name (e.g., UV-5RM)"),
) -> None:
    """Show detailed configuration for a specific model."""
    print_header(f"Model Configuration: {model}")
    
    # Check serial flash configs first
    if model in SERIAL_FLASH_CONFIGS:
        cfg = SERIAL_FLASH_CONFIGS[model]
        
        table = Table(title=f"{model} Serial Flash Config")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Logo Size", f"{cfg['size'][0]}x{cfg['size'][1]} pixels")
        table.add_row("Color Mode", cfg.get("color_mode", "N/A"))
        table.add_row("Start Address", f"0x{cfg.get('start_addr', 0):04X}")
        table.add_row("Block Size", str(cfg.get("block_size", 64)))
        table.add_row("Encryption", "Yes" if cfg.get("encrypt", False) else "No")
        table.add_row("Baud Rate", str(cfg.get("baudrate", 9600)))
        table.add_row("Timeout", f"{cfg.get('timeout', 3.0)}s")
        
        # Magic bytes
        magic = cfg.get("magic", b"")
        if len(magic) == 16:
            table.add_row("Protocol", "UV17Pro (16-byte magic)")
            try:
                table.add_row("Magic String", magic.decode("ascii"))
            except UnicodeDecodeError:
                table.add_row("Magic Bytes", magic.hex().upper())
        else:
            table.add_row("Protocol", "UV5R (7-byte magic)")
            table.add_row("Magic Bytes", magic.hex().upper())
        
        if cfg.get("encrypt"):
            key = cfg.get("key", b"")
            table.add_row("Encryption Key", key.hex().upper())
        
        console.print(table)
        
        if cfg.get("post_ident_magics"):
            console.print()
            print_warning("This model uses additional post-ident magic sequences.")
        
        return
    
    # Check model configs
    if model in MODEL_CONFIGS:
        cfg = MODEL_CONFIGS[model]
        
        table = Table(title=f"{model} Clone Config")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Name", cfg.name)
        
        if cfg.logo_region:
            table.add_row("Logo Start", f"0x{cfg.logo_region.start:04X}")
            table.add_row("Logo Length", f"{cfg.logo_region.length} bytes")
            table.add_row("Block Size", str(cfg.logo_region.block_size))
        else:
            table.add_row("Logo Region", "[yellow]Not defined - requires discovery[/yellow]")
        
        if cfg.scan_ranges:
            ranges = ", ".join(f"0x{s:04X}-0x{e:04X}" for s, e in cfg.scan_ranges)
            table.add_row("Scan Ranges", ranges)
        else:
            table.add_row("Scan Ranges", "[yellow]None defined[/yellow]")
        
        console.print(table)
        return
    
    # Model not found
    print_error(f"Model '{model}' not found.")
    console.print()
    console.print("Available models:")
    all_models = sorted(set(list(SERIAL_FLASH_CONFIGS.keys()) + list(MODEL_CONFIGS.keys())))
    for m in all_models:
        console.print(f"  - {m}")
    sys.exit(1)


@app.command()
def detect(
    port: str = typer.Option(..., "--port", "-p", help="Serial port"),
    model: Optional[str] = typer.Option(None, "--model", help="Override model name"),
) -> None:
    """Identify radio model and firmware."""
    print_header("Detect Radio")

    console.print(f"Port: {port}")

    transport = None
    try:
        transport = UV5RMTransport(port)
        transport.open()
        protocol = UV5RMProtocol(transport)
        ident_result = protocol.identify_radio()
        transport.close()

        model_name = model or ident_result["model"]

        table = Table(title="Radio Identification")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Model", model_name)
        table.add_row("Firmware", ident_result["version"].decode("latin-1", errors="ignore"))
        table.add_row("Ident", ident_result["ident"].hex().upper())
        table.add_row("Dropped Byte", str(ident_result["has_dropped_byte"]))

        console.print(table)
        print_success("Radio detected")
    except Exception as exc:
        print_error(f"Detect failed: {exc}")
        sys.exit(1)


@app.command()
def inspect_img(image: str = typer.Argument(..., help="Path to clone image file")) -> None:
    """Inspect CHIRP clone image for structure and safety."""
    print_header("Image Inspection")
    
    if not Path(image).exists():
        print_error(f"File not found: {image}")
        sys.exit(1)
    
    # Call the inspection tool
    import subprocess
    result = subprocess.run(
        ["python", "tools/inspect_img.py", image],
        cwd=Path(__file__).parent.parent.parent,
    )
    sys.exit(result.returncode)


@app.command()
def scan_logo(image: str = typer.Argument(..., help="Path to clone image file")) -> None:
    """Scan for candidate logo bitmap regions and export PNG previews."""
    print_header("Bitmap Candidate Scan")
    
    if not Path(image).exists():
        print_error(f"File not found: {image}")
        sys.exit(1)
    
    # Call the scanning tool
    import subprocess
    result = subprocess.run(
        ["python", "tools/scan_bitmap_candidates.py", image],
        cwd=Path(__file__).parent.parent.parent,
    )
    sys.exit(result.returncode)


@app.command()
def patch_logo(
    image: str = typer.Argument(..., help="Path to clone image"),
    logo_image: str = typer.Argument(..., help="Path to logo PNG/JPG"),
    offset: str = typer.Option(..., "--offset", "-o", help="Offset: decimal (4096), hex (0x1000), or suffix (1000h)"),
    format: str = typer.Option(
        "row_msb",
        "--format", "-f",
        help="Bitmap format: row_msb|row_lsb|page_msb|page_lsb",
    ),
    size: str = typer.Option("128x64", "--size", "-s", help="Image size WxH (default 128x64)"),
) -> None:
    """
    Patch logo into clone image (offline, no radio).
    
    Example:
        baofeng-logo-flasher patch-logo clone.img mylogo.png --offset 0x5A0 --format row_msb
    """
    print_header("Offline Logo Patch")
    
    # Verify inputs
    if not Path(image).exists():
        print_error(f"Image not found: {image}")
        sys.exit(1)
    
    if not Path(logo_image).exists():
        print_error(f"Logo image not found: {logo_image}")
        sys.exit(1)
    
    # Parse offset
    offset_int = parse_offset(offset)
    if offset_int is None:
        print_error("Offset is required")
        sys.exit(1)
    
    # Parse size
    try:
        width, height = map(int, size.lower().split('x'))
    except ValueError:
        print_error(f"Invalid size format: {size} (use WxH like 128x64)")
        sys.exit(1)
    
    # Verify format
    try:
        bitmap_fmt = parse_bitmap_format(format)
    except typer.BadParameter as e:
        print_error(str(e))
        sys.exit(1)
    
    console.print(f"Image:      {image}")
    console.print(f"Logo:       {logo_image}")
    console.print(f"Offset:     0x{offset_int:06X}")
    console.print(f"Format:     {bitmap_fmt.value}")
    console.print(f"Size:       {width}x{height}")
    console.print()
    
    try:
        # Convert image
        codec = LogoCodec(bitmap_fmt)
        logo_data = codec.convert_image(logo_image, (width, height))
        
        print_success(f"Logo converted: {len(logo_data)} bytes")
        
        # Patch
        patcher = LogoPatcher()
        result = patcher.patch_image(image, offset_int, logo_data)
        
        print_success(f"Patch applied at 0x{offset_int:06X}")
        print_success(f"Before: {result['before_hash'][:16]}...")
        print_success(f"After:  {result['after_hash'][:16]}...")
        print_success(f"Backup: {result['backup_info']['path']}")
        console.print()
        print_success("Image patched successfully!")
    
    except Exception as e:
        print_error(f"Patch failed: {e}")
        sys.exit(1)


@app.command()
def read_clone(
    port: str = typer.Option(..., "--port", "-p", help="Serial port (e.g., /dev/ttyUSB0)"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Save to file"),
) -> None:
    """Download clone from radio and save to file."""
    print_header("Download Clone from Radio")
    
    console.print(f"Port: {port}")
    
    try:
        transport = UV5RMTransport(port)
        transport.open()
        
        with Progress(
            TextColumn("[{task.description}]"),
            BarColumn(),
            TextColumn("[{task.percentage:.0f}%]"),
            console=console,
        ) as progress:
            task = progress.add_task("Connecting...", total=100)
            protocol = UV5RMProtocol(transport)
            
            progress.update(task, description="Identifying radio...")
            ident_result = protocol.identify_radio()
            progress.update(task, advance=25)
            
            progress.update(task, description="Downloading clone...")
            clone_data = protocol.download_clone()
            progress.update(task, advance=50)
            
            progress.update(task, description="Closing connection...")
            transport.close()
            progress.update(task, advance=25)
        
        # Display results
        table = Table(title="Radio Information")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Model", ident_result['model'])
        table.add_row("Firmware", ident_result['version'].decode('latin-1', errors='ignore'))
        table.add_row("Dropped Byte", str(ident_result['has_dropped_byte']))
        table.add_row("Clone Size", f"{len(clone_data):,} bytes")
        
        console.print(table)
        
        # Save to file
        if output:
            output_path = Path(output)
            output_path.write_bytes(clone_data)
            print_success(f"Clone saved to {output_path}")
        else:
            print_success("Clone downloaded successfully")
    
    except Exception as e:
        print_error(f"Download failed: {e}")
        sys.exit(1)


@app.command("download-logo")
def download_logo(
    port: str = typer.Option(..., "--port", "-p", help="Serial port"),
    out: Optional[str] = typer.Option(None, "--out", help="Output BMP file"),
    model: Optional[str] = typer.Option(None, "--model", help="Override model name"),
    logo_start: Optional[str] = typer.Option(None, "--logo-start", help="Logo start address"),
    logo_length: Optional[str] = typer.Option(None, "--logo-length", help="Logo length"),
    block_size: Optional[str] = typer.Option(None, "--block-size", help="Block size"),
    discover: bool = typer.Option(False, "--discover", help="Discover logo region"),
    scan_start: Optional[str] = typer.Option(None, "--scan-start", help="Discovery scan start"),
    scan_end: Optional[str] = typer.Option(None, "--scan-end", help="Discovery scan end"),
    scan_stride: Optional[str] = typer.Option(None, "--scan-stride", help="Discovery scan stride"),
    raw: bool = typer.Option(False, "--raw", help="Save raw bytes without BMP validation"),
) -> None:
    """Download boot logo from the radio."""
    print_header("Download Boot Logo")

    console.print(f"Port: {port}")

    logo_start_val = parse_int(logo_start, "logo-start")
    logo_length_val = parse_int(logo_length, "logo-length")
    block_size_val = parse_int(block_size, "block-size")
    scan_start_val = parse_int(scan_start, "scan-start")
    scan_end_val = parse_int(scan_end, "scan-end")
    scan_stride_val = parse_int(scan_stride, "scan-stride")

    try:
        transport = UV5RMTransport(port)
        transport.open()
        protocol = UV5RMProtocol(transport)
        ident_result = protocol.identify_radio()

        model_name = model or ident_result["model"]
        service = BootLogoService(protocol)

        config = MODEL_CONFIGS.get(
            model_name,
            BootLogoModelConfig(name=model_name, logo_region=None, scan_ranges=[]),
        )

        if logo_start_val is not None and logo_length_val is not None:
            region = service.resolve_logo_region(
                config,
                logo_start=logo_start_val,
                logo_length=logo_length_val,
                block_size=block_size_val,
            )
        elif discover:
            if scan_start_val is None or scan_end_val is None:
                raise BootLogoError("Discovery requires --scan-start and --scan-end")
            ranges = [(scan_start_val, scan_end_val)]
            stride = scan_stride_val or 0x10
            region = service.discover_logo_region(
                ranges,
                block_size=block_size_val or 0x40,
                scan_stride=stride,
            )
        else:
            region = service.resolve_logo_region(config, block_size=block_size_val)

        data = bytearray()
        end = region.start + region.length

        with Progress(
            TextColumn("[{task.description}]"),
            BarColumn(),
            TextColumn("[{task.percentage:.0f}%]"),
            console=console,
        ) as progress:
            task = progress.add_task("Reading logo...", total=region.length)
            for addr in range(region.start, end, region.block_size):
                size = min(region.block_size, end - addr)
                block = protocol.read_block(addr, size)
                data.extend(block)
                progress.update(task, advance=len(block))

        transport.close()

        if not raw:
            validate_bmp_bytes(bytes(data), BOOT_LOGO_SIZE)

        output_path = Path(out) if out else None
        if output_path is None:
            safe_model = model_name.replace(" ", "_")
            output_path = Path(f"boot_logo_{safe_model}.{'bin' if raw else 'bmp'}")

        output_path.write_bytes(bytes(data))
        print_success(f"Saved {len(data)} bytes to {output_path}")
    except Exception as exc:
        print_error(f"Download failed: {exc}")
        sys.exit(1)
    finally:
        if transport is not None:
            transport.close()


@app.command("upload-logo")
def upload_logo(
    port: str = typer.Option(..., "--port", "-p", help="Serial port"),
    image: str = typer.Option(..., "--in", "-i", help="Input image (BMP/PNG/JPG)"),
    model: Optional[str] = typer.Option(None, "--model", help="Override model name"),
    logo_start: Optional[str] = typer.Option(None, "--logo-start", help="Logo start address"),
    logo_length: Optional[str] = typer.Option(None, "--logo-length", help="Logo length"),
    block_size: Optional[str] = typer.Option(None, "--block-size", help="Block size"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate only, no write"),
    yes: bool = typer.Option(False, "--yes", help="Skip confirmation prompt"),
    discover: bool = typer.Option(False, "--discover", help="Discover logo region"),
    scan_start: Optional[str] = typer.Option(None, "--scan-start", help="Discovery scan start"),
    scan_end: Optional[str] = typer.Option(None, "--scan-end", help="Discovery scan end"),
    scan_stride: Optional[str] = typer.Option(None, "--scan-stride", help="Discovery scan stride"),
    accept_discovered: bool = typer.Option(
        False,
        "--accept-discovered",
        help="Allow writes to discovered logo region",
    ),
    write: bool = typer.Option(
        False,
        "--write",
        help="Required flag to enable actual write to radio",
    ),
) -> None:
    """Upload a boot logo to the radio."""
    print_header("Upload Boot Logo")

    if not Path(image).exists():
        print_error(f"File not found: {image}")
        sys.exit(1)

    logo_start_val = parse_int(logo_start, "logo-start")
    logo_length_val = parse_int(logo_length, "logo-length")
    block_size_val = parse_int(block_size, "block-size")
    scan_start_val = parse_int(scan_start, "scan-start")
    scan_end_val = parse_int(scan_end, "scan-end")
    scan_stride_val = parse_int(scan_stride, "scan-stride")

    transport = None
    try:
        transport = UV5RMTransport(port)
        transport.open()
        protocol = UV5RMProtocol(transport)
        ident_result = protocol.identify_radio()

        model_name = model or ident_result["model"]
        service = BootLogoService(protocol)

        config = MODEL_CONFIGS.get(
            model_name,
            BootLogoModelConfig(name=model_name, logo_region=None, scan_ranges=[]),
        )

        if logo_start_val is not None and logo_length_val is not None:
            region = service.resolve_logo_region(
                config,
                logo_start=logo_start_val,
                logo_length=logo_length_val,
                block_size=block_size_val,
            )
        elif discover:
            if scan_start_val is None or scan_end_val is None:
                raise BootLogoError("Discovery requires --scan-start and --scan-end")
            if not accept_discovered and not dry_run:
                raise BootLogoError(
                    "Discovered region requires --accept-discovered for writes"
                )
            ranges = [(scan_start_val, scan_end_val)]
            stride = scan_stride_val or 0x10
            region = service.discover_logo_region(
                ranges,
                block_size=block_size_val or 0x40,
                scan_stride=stride,
            )
        else:
            region = service.resolve_logo_region(config, block_size=block_size_val)

        logo_bytes = service.prepare_logo_bytes(image)
        validate_bmp_bytes(logo_bytes, BOOT_LOGO_SIZE)

        if len(logo_bytes) != region.length:
            raise BootLogoError(
                f"Logo data length {len(logo_bytes)} does not match region {region.length}"
            )

        if dry_run:
            print_success("Dry run complete: no data written")
            transport.close()
            return

        # Require --write flag and typed confirmation
        confirm_write_with_details(
            write_flag=write,
            model=model_name,
            target_region=f"Logo region 0x{region.start:06X}-0x{region.start + region.length:06X}",
            bytes_length=len(logo_bytes),
            offset=region.start,
        )

        end = region.start + region.length
        offset = 0

        with Progress(
            TextColumn("[{task.description}]"),
            BarColumn(),
            TextColumn("[{task.percentage:.0f}%]"),
            console=console,
        ) as progress:
            task = progress.add_task("Writing logo...", total=region.length)
            for addr in range(region.start, end, region.block_size):
                size = min(region.block_size, end - addr)
                chunk = logo_bytes[offset:offset + size]
                protocol.write_block(addr, chunk)
                offset += size
                progress.update(task, advance=len(chunk))

        readback = bytearray()
        for addr in range(region.start, end, region.block_size):
            size = min(region.block_size, end - addr)
            readback.extend(protocol.read_block(addr, size))

        if bytes(readback) != logo_bytes:
            raise BootLogoError("Readback verification failed")

        transport.close()
        print_success("Boot logo uploaded")
    except typer.Abort:
        print_warning("Upload cancelled")
        sys.exit(0)
    except Exception as exc:
        print_error(f"Upload failed: {exc}")
        sys.exit(1)
    finally:
        if transport is not None:
            transport.close()


@app.command()
def flash_logo(
    port: str = typer.Option(..., "--port", "-p", help="Serial port"),
    image: str = typer.Option(..., "--image", "-i", help="Logo PNG/JPG file"),
    offset: str = typer.Option(..., "--offset", "-o", help="Offset: decimal (4096), hex (0x1000), or suffix (1000h)"),
    format: str = typer.Option("row_msb", "--format", "-f", help="Bitmap format"),
    size: str = typer.Option("128x64", "--size", "-s", help="Logo size WxH"),
    no_upload: bool = typer.Option(False, "--no-upload", help="Patch only, don't upload"),
    write: bool = typer.Option(False, "--write", help="Required flag to enable actual write to radio"),
) -> None:
    """
    Complete workflow: download clone → backup → patch logo → upload → verify.
    
    Steps:
    1. Download current radio clone
    2. Backup original
    3. Patch logo into clone
    4. Upload patched clone to radio
    5. Verify success
    """
    print_header("Flash Logo to Radio")
    
    # Parse offset first
    offset_int = parse_offset(offset)
    if offset_int is None:
        print_error("Offset is required")
        sys.exit(1)
    
    # Parse bitmap format
    try:
        bitmap_fmt = parse_bitmap_format(format)
    except typer.BadParameter as e:
        print_error(str(e))
        sys.exit(1)
    
    console.print(f"Port: {port}")
    console.print(f"Logo: {image}")
    console.print(f"Offset: 0x{offset_int:06X}")
    console.print(f"Format: {bitmap_fmt.value}")
    console.print(f"Size: {size}")
    
    if not Path(image).exists():
        print_error(f"Logo file not found: {image}")
        sys.exit(1)
    
    try:
        with Progress(
            TextColumn("[{task.description}]"),
            BarColumn(),
            TextColumn("[{task.percentage:.0f}%]"),
            console=console,
        ) as progress:
            # Step 1: Download clone
            task1 = progress.add_task("Downloading clone from radio...", total=100)
            transport = UV5RMTransport(port)
            transport.open()
            
            protocol = UV5RMProtocol(transport)
            ident_result = protocol.identify_radio()
            progress.update(task1, advance=25)
            
            clone_data = protocol.download_clone()
            progress.update(task1, advance=50)
            
            # Step 2: Backup original clone BEFORE any modification
            # Create patcher and backup the raw bytes we downloaded
            task2 = progress.add_task("Backing up original clone...", total=100)
            patcher = LogoPatcher()
            
            # Use backup_bytes to save raw clone data (critical: backup before write)
            backup_info = patcher.backup_bytes(
                name=f"clone_before_flash_{ident_result['model']}",
                data=clone_data,
            )
            if backup_info is None:
                raise RuntimeError("Failed to create backup. Aborting for safety.")
            
            progress.update(task2, advance=100)
            
            # Step 3: Patch logo
            task3 = progress.add_task("Patching logo...", total=100)
            codec = LogoCodec(bitmap_fmt, dither=False)
            w, h = map(int, size.split('x'))
            logo_data = codec.convert_image(image, (w, h))
            progress.update(task3, advance=50)
            
            # Create temp file for patching
            import tempfile
            with tempfile.NamedTemporaryFile(suffix=".img", delete=False) as tmp:
                tmp.write(clone_data)
                tmp_path = tmp.name
            
            patch_result = patcher.patch_image(tmp_path, offset_int, logo_data, verify=True)
            patched_data = Path(tmp_path).read_bytes()
            progress.update(task3, advance=50)
            
            # Step 4: Upload patched clone (requires --write flag and confirmation)
            if not no_upload:
                # Require --write flag and typed confirmation before actual write
                confirm_write_with_details(
                    write_flag=write,
                    model=ident_result['model'],
                    target_region=f"Full clone with logo at 0x{offset_int:06X}",
                    bytes_length=len(patched_data),
                    offset=offset_int,
                )
                
                task4 = progress.add_task("Uploading patched clone to radio...", total=100)
                protocol.upload_clone(patched_data)
                progress.update(task4, advance=100)
            else:
                # Just save patched clone for manual upload
                patched_path = Path("clone_patched.img")
                patched_path.write_bytes(patched_data)
                console.print(f"\n[yellow]Patched clone saved to: {patched_path}[/yellow]")
            
            transport.close()
        
        # Show results
        table = Table(title="Flash Results")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Radio Model", ident_result['model'])
        table.add_row("Original Size", f"{len(clone_data):,} bytes")
        table.add_row("Logo Offset", f"0x{offset_int:06X}")
        table.add_row("Logo Size", f"{len(logo_data):,} bytes")
        table.add_row("Format", bitmap_fmt.value)
        table.add_row("Upload", "No" if no_upload else "Yes")
        table.add_row("Backup", backup_info['path'])
        
        console.print(table)
        print_success("Logo flashed successfully!" if not no_upload else "Logo patched successfully (not uploaded)")
    
    except Exception as e:
        print_error(f"Flash failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


@app.command()
def verify_image(
    image: str = typer.Argument(..., help="Path to clone image"),
) -> None:
    """Verify image against protocol assumptions."""
    print_header("Image Verification")
    
    if not Path(image).exists():
        print_error(f"File not found: {image}")
        sys.exit(1)
    
    result = ProtocolVerifier.verify_before_write(image)
    
    table = Table(title="Verification Results")
    table.add_column("Check", style="cyan")
    table.add_column("Result", style="green")
    
    for check, passed in result['checks'].items():
        status = "✓" if passed else "✗"
        table.add_row(check, status)
    
    console.print(table)
    
    if result['blocking_issues']:
        console.print()
        print_error(f"{len(result['blocking_issues'])} blocking issues:")
        for issue in result['blocking_issues']:
            console.print(f"  • {issue}")
    
    if result['warnings']:
        console.print()
        print_warning(f"{len(result['warnings'])} warnings:")
        for warning in result['warnings']:
            console.print(f"  • {warning}")
    
    console.print()
    if result['safe_to_write']:
        print_success("Image verification PASSED")
    else:
        print_error("Image verification FAILED")
        sys.exit(1)


def main() -> None:
    """Main entry point."""
    try:
        app()
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user[/yellow]")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[red bold]Fatal error:[/red bold] {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
