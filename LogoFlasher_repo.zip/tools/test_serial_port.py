#!/usr/bin/env python
"""Quick serial port diagnostic tool."""

import sys
import serial
from pathlib import Path

sys.path.insert(0, 'src')
from baofeng_logo_flasher.boot_logo import list_serial_ports

def test_port(port: str, baudrate: int = 38400, timeout: float = 2.0):
    """Test if a serial port responds."""
    print(f"\n🔍 Testing port: {port}")
    print(f"   Baud rate: {baudrate}")
    print(f"   Timeout: {timeout}s")
    
    try:
        ser = serial.Serial(port, baudrate, timeout=timeout)
        print(f"   ✓ Port opened successfully")
        
        # Clear any buffered data
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        
        # Try sending the magic bytes
        magic = b"PROGRAM"
        print(f"\n📤 Sending magic: {magic}")
        bytes_sent = ser.write(magic)
        print(f"   Sent {bytes_sent} bytes")
        ser.flush()
        
        # Try to read response
        print(f"⏳ Waiting for response...")
        import time
        time.sleep(0.2)  # Give radio time to respond
        
        ack = ser.read(1)
        
        if ack:
            print(f"   ✓ Received: {ack.hex()} ({ord(ack)})")
            if ack == b'\x06':
                print(f"   ✓ **CORRECT ACK** (0x06)")
                print(f"\n✅ Radio is responding correctly!")
            elif ack == b'\x00':
                print(f"   ✓ Got null byte (0x00) - This is OK for some models")
                print(f"\n✅ Radio is responding!")
            else:
                print(f"   ⚠️ Unexpected response (expected 0x06 or 0x00)")
        else:
            print(f"   ✗ No response (timeout)")
            print(f"\n❌ Radio not responding. Check:")
            print(f"   - Is the radio powered ON?")
            print(f"   - Is it connected via USB?")
            print(f"   - Is it in programming mode?")
            print(f"   - Try unplugging/replugging the cable")
        
        ser.close()
        print(f"\n✓ Port closed")
        
    except serial.SerialException as e:
        print(f"   ✗ Serial error: {e}")
    except Exception as e:
        print(f"   ✗ Error: {e}")

def main():
    print("=" * 60)
    print("  BAOFENG SERIAL PORT DIAGNOSTIC")
    print("=" * 60)
    
    ports = list_serial_ports()
    
    print(f"\n📡 Available serial ports: {len(ports)}")
    for p in ports:
        print(f"   - {p}")
    
    if not ports:
        print("\n⚠️ No serial ports found!")
        return
    
    # Test the first port
    test_port(ports[0])
    
    # Or test a specific port if provided
    if len(sys.argv) > 1:
        custom_port = sys.argv[1]
        print(f"\n\n(Testing custom port: {custom_port})")
        test_port(custom_port)

if __name__ == "__main__":
    main()
