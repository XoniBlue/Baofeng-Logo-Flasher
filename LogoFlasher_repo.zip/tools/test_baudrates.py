#!/usr/bin/env python
"""Test multiple baud rates."""

import sys
import serial

sys.path.insert(0, 'src')

def test_baudrates(port: str):
    """Try common baud rates."""
    rates = [9600, 38400, 115200, 19200, 57600]
    
    print(f"\n🔍 Testing multiple baud rates on {port}")
    print("=" * 60)
    
    for rate in rates:
        try:
            ser = serial.Serial(port, rate, timeout=1.5)
            
            # Send magic
            ser.write(b"PROGRAM")
            ack = ser.read(1)
            
            ser.close()
            
            if ack:
                print(f"✓ {rate:6d} baud: Got response {ack.hex()}")
                if ack == b'\x06':
                    print(f"         ✅ CORRECT ACK!")
            else:
                print(f"✗ {rate:6d} baud: No response")
        except Exception as e:
            print(f"✗ {rate:6d} baud: Error - {e}")

if __name__ == "__main__":
    port = sys.argv[1] if len(sys.argv) > 1 else "/dev/cu.Plser"
    test_baudrates(port)
