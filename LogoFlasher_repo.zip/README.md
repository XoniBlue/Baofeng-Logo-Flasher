# Baofeng UV-5RM Logo Flasher

🔧 **Standalone, safety-first Python tool for modifying radio logos**

A complete CLI + optional Streamlit UI for safe inspection, modification, and upload of custom logos to Baofeng UV-5RM radios. Works entirely offline for image analysis and patching.

---

## ⚠️ CRITICAL SAFETY FIRST

**This tool is READ-ONLY by default.** Every write operation requires:

1. ✅ Explicit `--write` flag
2. ✅ User typing exact confirmation: `WRITE LOGO NOW`
3. ✅ Full backup of original region before modification
4. ✅ SHA256 verification after write
5. ✅ One-click restore capability

**You can always restore from backups** in case anything goes wrong.

---

## 📋 Quick Start (macOS)

### 1. Install Python 3.9+

```bash
# Using brew
brew install python3

# Or from https://www.python.org/downloads/
```

### 2. Clone Repository

```bash
cd ~/Projects  # or wherever you keep code
git clone https://github.com/yourusername/baofeng-logo-flasher.git
cd baofeng-logo-flasher
```

### 3. Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate
```

### 4. Install Project

```bash
# Install CLI only (no web UI)
pip install -e .

# Install with optional Streamlit web UI
pip install -e ".[ui]"

# Install with development tools
pip install -e ".[dev]"

# Install everything (UI + dev tools)
pip install -e ".[ui,dev]"
```

### 5. Verify Installation

```bash
baofeng-logo-flasher --help
```

Should print the CLI help menu.

---

## 🎯 Typical Workflow

### Phase 1: Understand Your Radio's Image Layout

Your image file is **63 KB** (much larger than the 8 KB protocol expects). This is normal for CHIRP.

**Step 1: Inspect the image**

```bash
baofeng-logo-flasher inspect-img Baofeng_5RM_20260204.img
```

**Output:** File size, entropy, header analysis, safety warnings.

### Phase 2: Find the Logo Location

**Step 2: Scan for bitmap regions**

```bash
baofeng-logo-flasher scan-logo Baofeng_5RM_20260204.img
```

**Output:** PNG previews in `out/previews/` showing candidate logo locations at various resolutions and bit orders.

**Step 3: Visually inspect the PNGs**

Open the files in `out/previews/` and look for recognizable logo/UI elements. Note:
- The offset (e.g., `0x5A0`)
- The format (e.g., `row_msb`)

### Phase 3: Patch Your Logo (Offline)

**Step 4: Prepare your logo image**

Create a PNG or JPG with your custom logo.

**Step 5: Patch the image**

```bash
baofeng-logo-flasher patch-logo Baofeng_5RM_20260204.img mylogo.png \
  --offset 0x5A0 \
  --format row_msb \
  --size 128x64
```

**Output:**
- Modified image
- Full backup in `backups/<timestamp>/`
- SHA256 hashes before/after
- Indication of success

### Phase 4: Upload to Radio (Optional - Manual)

Once you're confident the patch is correct:

1. Open your favorite CHIRP radio programming software
2. Load the patched `.img` file
3. Write to radio as usual

Or use command-line:

```bash
# Download existing clone from radio (for backup)
baofeng-logo-flasher read-clone --port /dev/ttyUSB0 --output backup.img

# Patch the clone
baofeng-logo-flasher patch-logo backup.img mylogo.png --offset 0x5A0

# Upload patched clone back (future feature)
# baofeng-logo-flasher flash-logo --port /dev/ttyUSB0 --image patched.img --write
```

---

## 📚 Complete Command Reference

### inspect-img
Analyze image structure and safety metrics.

```bash
baofeng-logo-flasher inspect-img <file.img>
```

**Shows:**
- File size, SHA256, entropy
- First/last 128 bytes in hex
- Repeating patterns
- Safety warnings vs. protocol expectations

### scan-logo
Find candidate logo bitmap regions.

```bash
baofeng-logo-flasher scan-logo <file.img>
```

**Shows:**
- 20 candidates ranked by "quality"
- PNG previews in `out/previews/`
- Offset, resolution, format for each
- Visual confirmation of logo location

### patch-logo (Offline)
Modify image without connecting to radio.

```bash
baofeng-logo-flasher patch-logo <clone.img> <logo.png> \
  --offset 0x5A0 \
  --format row_msb \
  --size 128x64
```

**Options:**
- `--offset`: Memory offset in hex (e.g., `0x1000`)
- `--format`: Bitmap format
  - `row_msb` (most common) - row-by-row, bit 7 = leftmost
  - `row_lsb` - row-by-row, bit 0 = leftmost
  - `page_msb` - SSD1306-style columns
  - `page_lsb` - SSD1306-style columns, LSB
- `--size`: Image dimensions (default `128x64`)

**Output:**
- Modified clone file
- Backups in `backups/<timestamp>/`
- Before/after hashes
- Restore command if needed

### read-clone (Serial)
Download image from radio.

```bash
baofeng-logo-flasher read-clone --port /dev/ttyUSB0 --output my_radio.img
```

**Requires:** Radio connected via USB cable, proper drivers installed.

### ports
List available serial ports.

```bash
baofeng-logo-flasher ports
```

**Shows:**
- All serial ports on system
- Device names, descriptions

### verify-image
Check image for safety before writing.

```bash
baofeng-logo-flasher verify-image <clone.img>
```

**Checks:**
- File exists and is readable
- Size within expected ranges
- Logo offset is documented
- All regions in bounds

---

## 🖥️ Optional Streamlit UI

For visual users, a web-based UI is available:

```bash
streamlit run src/baofeng_logo_flasher/streamlit_ui.py
```

**Features:**
- Upload and inspect images
- Live logo preview
- Interactive bitmap format selector
- Download patched images
- Verification dashboard

---

## 📦 Project Structure

```
baofeng-logo-flasher/
├── pyproject.toml                  # Project config + dependencies
├── README.md                       # This file
│
├── src/baofeng_logo_flasher/
│   ├── __init__.py
│   ├── cli.py                      # Typer CLI (all commands)
│   ├── streamlit_ui.py             # Optional web UI
│   ├── logo_codec.py               # Image format conversion
│   ├── logo_patcher.py             # Safe patching logic
│   ├── protocol_verifier.py        # Safety verification
│   │
│   └── protocol/                   # CHIRP integration
│       ├── uv5rm_transport.py      # Serial communication
│       ├── uv5rm_protocol.py       # High-level protocol
│       └── __init__.py
│
├── tools/                          # Standalone utilities
│   ├── inspect_img.py              # Image structure analysis
│   └── scan_bitmap_candidates.py   # Find logo location
│
├── tests/                          # Pytest test suite
│   └── test_logo_codec.py          # Pack/unpack roundtrip tests
│
└── docs/                           # Documentation
    ├── IMAGE_LAYOUT.md             # Know/unknown about your radio
    └── PROTOCOL.md                 # (From extracted CHIRP docs)
```

---

## 🔧 Troubleshooting

### "ModuleNotFoundError: No module named 'baofeng_logo_flasher'"

You need to install the project:

```bash
pip install -e .
```

### "Serial port not found" or "Permission denied"

**macOS Serial Port Issues:**

1. **Check if port exists:**
   ```bash
   baofeng-logo-flasher ports
   ```

2. **Install CH340 driver** (common for USB adapters):
   ```bash
   brew install ch340g-ch34x-driver
   ```

3. **Add user to dialout group:**
   ```bash
   sudo dserial /dev/ttyUSB0 115200
   ```

### "Image too small" or size mismatch warnings

This is expected if you're using a CHIRP image that's larger than 8 KB. The tool will warn you but still work.

### "Logo offset not yet determined"

Use the `scan-logo` command to find where the logo lives in your specific image:

```bash
baofeng-logo-flasher scan-logo <your_image.img>
```

---

## 🧪 Testing

Full test suite with pytest:

```bash
pytest tests/ -v
```

Tests cover:
- ✅ Image pack/unpack roundtrips all 4 formats
- ✅ Logo patching and restore
- ✅ Backup creation and verification
- ✅ Bounds checking

---

## 📖 Deep Dives

For detailed information:

- **IMAGE_LAYOUT.md** - What we know/don't know about your radio
- **PROTOCOL.md** - Full CHIRP protocol extraction
- **CLI Help:**
  ```bash
  baofeng-logo-flasher --help
  baofeng-logo-flasher patch-logo --help
  ```

---

## 🚀 Advanced: Manual Protocol Testing

If you're debugging or curious about the protocol:

```python
from baofeng_logo_flasher.protocol import UV5RMTransport, UV5RMProtocol

# Open serial connection
transport = UV5RMTransport("/dev/ttyUSB0")
transport.open()

# Identify radio
protocol = UV5RMProtocol(transport)
info = protocol.identify_radio()
print(f"Model: {info['model']}")
print(f"Firmware: {info['version']}")

# Download clone (6-8 KB)
clone = protocol.download_clone()
print(f"Downloaded: {len(clone)} bytes")

# Save it
with open("clone_from_radio.img", "wb") as f:
    f.write(clone)

transport.close()
```

---

## 📝 Example: Complete Logo Flash Workflow

```bash
# 1. Inspect your image
baofeng-logo-flasher inspect-img Baofeng_5RM_20260204.img

# 2. Discover logo location
baofeng-logo-flasher scan-logo Baofeng_5RM_20260204.img
# → Opens out/previews/*.png - visually identify logo

# 3. Prepare logo (use GIMP, Photoshop, or online tool)
# → Export as PNG, 128x64 recommended

# 4. Patch image offline (no radio needed!)
baofeng-logo-flasher patch-logo Baofeng_5RM_20260204.img mylogo.png \
  --offset 0x5A0 --format row_msb --size 128x64

# 5. Upload via CHIRP (or our tool when radio flashing is ready)
# → Open CHIRP, load clone_patched.img, write to radio

# 6. (Optional) Restore if needed
# rm -rf Baofeng_5RM_20260204.img
# cp backups/*/full_Baofeng_5RM_20260204.img ./
```

---

## 🤝 Contributing

Issues & PRs welcome! Especially:
- Testing on different radio models
- Documenting logo offsets for specific firmware versions
- Improving bitmap detection

---

## 📄 License

MIT License - See LICENSE file for details

---

## ⚡ Requirements

- **Python:** 3.9+
- **macOS:** 10.13+ (for serial port support)
- **Dependencies:**
  - `pyserial` - Serial device communication
  - `pillow` - Image processing
  - `typer` - CLI framework
  - `rich` - Beautiful terminal output
  - `streamlit` (optional) - Web UI

---

## 🎓 Learning Resources

Useful if you want to understand the internals:

1. UV-5RM Protocol: See `docs/PROTOCOL.md` (extracted from CHIRP)
2. CHIRP Project: https://chirp.danplanet.com/
3. Baofeng Community: https://www.baofengradio.com/
4. Monochrome Bitmap Formats: Common in embedded displays (SSD1306, etc.)

---

**Remember:** Always backup before writing, test on files first, and restore if anything seems wrong. Happy logo flashing! 🚀
