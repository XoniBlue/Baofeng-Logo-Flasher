"""Baofeng Logo Flasher test suite."""
