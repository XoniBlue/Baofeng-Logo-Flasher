"""Tests for boot logo flasher module."""

import tempfile
from pathlib import Path
from PIL import Image

from baofeng_logo_flasher.boot_logo import (
    SERIAL_FLASH_CONFIGS,
    baofeng_encrypt,
    convert_bmp_to_raw,
    flash_logo,
)


def _make_bmp(tmp_path, size=(160, 128)) -> str:
    """Create a temporary BMP file."""
    img = Image.new("RGB", size, color=(10, 20, 30))
    path = tmp_path / "logo.bmp"
    img.save(path, format="BMP")
    return str(path)


class TestEncryption:
    """Test Baofeng encryption."""
    
    def test_encrypt_length_stable(self):
        """Encrypted output should match input length."""
        data = b"\x01\x02\x03\x04\x05"
        out = baofeng_encrypt(data, key=b"\xAB")
        assert len(out) == len(data)
    
    def test_encrypt_not_identity(self):
        """Encryption should change the data."""
        data = b"\x00\x00\x00\x00"
        out = baofeng_encrypt(data, key=b"\xAB\xCD")
        assert out != data
    
    def test_encrypt_deterministic(self):
        """Same input should produce same output."""
        data = b"test data"
        out1 = baofeng_encrypt(data)
        out2 = baofeng_encrypt(data)
        assert out1 == out2


class TestBMPConversion:
    """Test BMP to raw conversion."""
    
    def test_convert_bmp_rgb_unencrypted(self):
        """Convert BMP to RGB raw (no encryption)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            bmp_path = _make_bmp(tmp_path, size=(160, 128))
            config = dict(SERIAL_FLASH_CONFIGS["UV-5RM"])
            config["encrypt"] = False
            
            raw = convert_bmp_to_raw(bmp_path, config)
            
            # 160 * 128 * 3 bytes for RGB
            assert len(raw) == 160 * 128 * 3
    
    def test_convert_bmp_encrypted(self):
        """Convert BMP to raw with encryption."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            bmp_path = _make_bmp(tmp_path, size=(160, 128))
            config = dict(SERIAL_FLASH_CONFIGS["UV-5RM"])
            config["encrypt"] = True
            
            raw = convert_bmp_to_raw(bmp_path, config)
            
            # 160 * 128 * 3 bytes for RGB (encrypted)
            assert len(raw) == 160 * 128 * 3
    
    def test_convert_bmp_resize(self):
        """BMP should be resized to target dimensions."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            # Create image with wrong size
            img = Image.new("RGB", (80, 64), color=(10, 20, 30))
            path = tmp_path / "wrong_size.bmp"
            img.save(path, format="BMP")
            
            config = dict(SERIAL_FLASH_CONFIGS["UV-5RM"])
            config["encrypt"] = False
            
            raw = convert_bmp_to_raw(str(path), config)
            
            # Should still be correct size after resize
            assert len(raw) == 160 * 128 * 3


class TestFlashSimulation:
    """Test flash operation in simulation mode."""
    
    def test_flash_simulate(self):
        """Simulation mode should not require actual serial."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            bmp_path = _make_bmp(tmp_path, size=(160, 128))
            
            result = flash_logo(
                port="SIMULATED",
                bmp_path=bmp_path,
                config=dict(SERIAL_FLASH_CONFIGS["UV-5RM"]),
                simulate=True,
            )
            
            assert "Simulation" in result
            assert "0x1000" in result  # start address


class TestModelConfigs:
    """Test model configurations."""
    
    def test_uv5rm_config_exists(self):
        """UV-5RM should be in configs."""
        assert "UV-5RM" in SERIAL_FLASH_CONFIGS
        config = SERIAL_FLASH_CONFIGS["UV-5RM"]
        assert config["size"] == (160, 128)
        assert config["encrypt"] is True
    
    def test_dm32uv_config_exists(self):
        """DM-32UV should be in configs."""
        assert "DM-32UV" in SERIAL_FLASH_CONFIGS
        config = SERIAL_FLASH_CONFIGS["DM-32UV"]
        assert config["size"] == (240, 320)
        assert config["encrypt"] is False
