# Image Layout Documentation

**CRITICAL:** This document explains what we know and what we still need to verify about your radio's image structure.

---

## 1. Extracted Protocol Assumptions

From CHIRP integration documentation (`uv5rm_protocol_summary.md`):

| Item | Value |
|------|-------|
| Main memory size | 0x1808 (6,152 bytes) |
| Auxiliary memory start | 0x1EC0 |
| Auxiliary memory end | 0x2000 |
| Total protocol expectation | ~8,192 bytes max |
| Radio models covered | UV-5R, UV-82, UV-6, F-11, etc. |

---

## 2. YOUR REAL IMAGE

File: `Baofeng_5RM_20260204.img`

| Property | Value |
|----------|-------|
| **Actual size** | **63,633 bytes** (0xF891) |
| Structure | CHIRP firmware dump |
| Format | Binary + base64-encoded JSON metadata at end |
| Contains | FRS frequency entries, settings, plus CHIRP metadata |

### Size Mismatch Analysis

- Expected by protocol: **~8 KB**
- Actual file size: **~64 KB**
- Difference: **+7.8 times larger**

This is **NORMAL**. CHIRP's clone image format includes:
1. Standard radio memory (what protocol assumes)
2. FRS preset frequencies (modern CHIRP feature)
3. Additional settings/calibration data
4. CHIRP metadata (JSON at end)

---

## 3. WHAT WE STILL DON'T KNOW (MUST VERIFY)

### Logo Memory Address

The extracted protocol documentation does NOT specify the exact address of the logo region.

Common possibilities:
- **0x1F00** (within protocol aux range) - unlikely, too small
- **0x2500** (after protocol range) - more likely
- **Unknown custom offset** - requires discovery

### Logo Format & Size

Assumptions:
- **Resolution:** Likely 128×64 or 128×32 (common LCD sizes)
- **Color depth:** Monochrome (1-bit, most likely)
- **Bit order:** Unknown (MSB-first or LSB-first)
- **Layout:** Unknown (row-major or SSD1306 page-major)

### Exact Layout of 63KB Image

The image appears to be:
```
0x0000-0x1800:  Main memory (0x1800 = 6144 bytes)
0x1800-0x1EC0:  Unknown (padding or settings?)
0x1EC0-0x2000:  Auxiliary memory (0x140 = 320 bytes)
0x2000-0xF880:  Unknown (FRS data? Settings? Firmware updates?)
0xF880-0xF891:  CHIRP metadata (base64-encoded JSON)
```

---

## 4. DISCOVERY WORKFLOW

To find the logo location safely:

### Step 1: Use the Scanning Tool

```bash
python tools/scan_bitmap_candidates.py Baofeng_5RM_20260204.img
```

This will:
- Search for any 1-bit bitmap blocks at standard resolutions
- Test 4 common bit orderings (MSB/LSB × row/column-major)
- Export PNG previews to `out/previews/`

### Step 2: Visual Inspection

1. Open the PNG files in `out/previews/`
2. Look for recognizable logo/UI elements
3. Note the offset and format that looks correct

### Step 3: Verify with Backup

1. Once you identify a candidate offset:
   ```bash
   baofeng-logo-flasher patch-logo Baofeng_5RM_20260204.img mylogo.png \
     --offset 0x5A0 \
     --format row_msb
   ```
2. Visually compare the patched region
3. Restore from backup if needed

### Step 4: Test on Real Radio (OPTIONAL)

Only after you're confident in the offset:
1. Download a clone from your radio: `--read-clone`
2. Apply the same patch
3. Upload back and verify visually

---

## 5. SAFETY GATES

The tool implements multiple safety checks:

### Pre-Write Verification

```
✓ File exists
✓ File readable  
⚠️  Logo offset NOT YET DETERMINED (user must confirm via scan)
✓ All regions in bounds
```

### Backup Strategy

Every write automatically:
1. Backs up the full image
2. Backs up the specific region being modified
3. Stores SHA256 hashes for verification
4. Allows one-click restore

### Verification After Write

All patches include:
- Hash before/after comparison
- Optional readback verification
- Prompt to restore if anything seems wrong

---

## 6. KNOWN WORKING EXAMPLES

**Currently:** None documented (awaiting your discovery!)

Once you find the logo location, document it here:

```
Radio Model: UV-5RM
Firmware: BFB...XXX
Logo Offset: 0x????
Logo Format: row_msb (or other)
Logo Size: 128x64 (or other)
Notes: [describe what works]
```

---

## 7. REMAINING UNKNOWNS

- [ ] Exact logo offset in 63KB image
- [ ] Logo resolution (128×64? 128×32? other?)
- [ ] Bitmap bit order (MSB vs LSB)
- [ ] Layout (row-major vs SSD1306 page-major)
- [ ] Whether logo region is compressed
- [ ] Whether logo update requires radio reboot

---

## 8. NEXT STEPS

1. **Run the scanner:**
   ```bash
   python tools/scan_bitmap_candidates.py Baofeng_5RM_20260204.img
   ```

2. **Inspect PNG previews** in `out/previews/` folder

3. **Identify the logo** candidate and its offset/format

4. **Document findings** by editing this file

5. **Test patch** on the file offline first

6. **[OPTIONAL] Test on real radio** after offline verification passes
