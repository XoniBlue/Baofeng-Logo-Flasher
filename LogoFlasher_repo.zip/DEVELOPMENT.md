# Development Guide

This document explains the architecture and how to extend the project.

---

## Architecture Overview

### Layer 0: Protocol (CHIRP Integration)

**Files:**
- `src/baofeng_logo_flasher/protocol/uv5rm_transport.py` - Low-level serial I/O
- `src/baofeng_logo_flasher/protocol/uv5rm_protocol.py` - High-level operations

**Responsibility:** Communication with Baofeng radios via serial port.

**Key Classes:**
- `UV5RMTransport` - Raw bytes in/out
- `UV5RMProtocol` - Clone download/upload, identification

**Not Modified:** Extracted from CHIRP, should work as-is.

### Layer 1: Image Analysis & Patching

**Files:**
- `src/baofeng_logo_flasher/logo_codec.py` - Image format conversion
- `src/baofeng_logo_flasher/logo_patcher.py` - Safe modification

**Responsibility:** Load images, convert between PNG and monochrome bitmap formats, patch image files with backups.

**Key Classes:**
- `LogoCodec` - PNG ↔ packed bitmap conversion
- `BitmapFormat` - Enum of 4 supported formats
- `LogoPatcher` - Safe patching with backups

### Layer 2: Safety Verification

**Files:**
- `src/baofeng_logo_flasher/protocol_verifier.py` - Pre-write checks

**Responsibility:** Verify image is safe before any write operations.

**Key Classes:**
- `ProtocolVerifier` - Image validation, safety gates

### Layer 3: User Interface

**CLI:**
- `src/baofeng_logo_flasher/cli.py` - Typer-based command-line interface

**Web UI (optional - requires `.[ui]` extra):**
- `src/baofeng_logo_flasher/streamlit_ui.py` - Optional Streamlit dashboard

To install the web UI:
```bash
pip install -e ".[ui]"
```

### Layer 4: Tools

**Discovery Tools:**
- `tools/inspect_img.py` - Image structure analysis
- `tools/scan_bitmap_candidates.py` - Find logo location via visual preview

---

## Code Organization

```
baofeng_logo_flasher/
├── __init__.py              # Package exports
├── cli.py                   # Main CLI entry point
├── streamlit_ui.py          # Optional web UI
│
├── logo_codec.py            # Image format conversion
├── logo_patcher.py          # File modification + backups
├── protocol_verifier.py     # Safety checks
│
└── protocol/                # CHIRP integration (external)
    ├── __init__.py
    ├── uv5rm_transport.py   # Serial I/O
    └── uv5rm_protocol.py    # High-level protocol
```

---

## Key Design Decisions

### 1. Read-Only Default

Every write operation requires explicit enable + user confirmation. No accidents.

### 2. Automatic Backups

All writes store:
- Full image backup
- Region-specific backup
- SHA256 hashes for verification

Users can always restore to original state.

### 3. Multi-Format Support

Logo codec supports 4 bitmap formats to handle unknowns during discovery phase:
- Row-major MSB-first (most common)
- Row-major LSB-first
- Column/page-major MSB (SSD1306-style)
- Column/page-major LSB

Allows visual scanning without needing to know exact format.

### 4. Image Layout Agnostic

The tool doesn't assume where the logo is. Users:
1. Scan for candidates (no assumptions)
2. Visually inspect PNG previews
3. Specify offset + format explicitly
4. Verify on real radio before mass production

---

## Testing Strategy

### Unit Tests (tests/test_logo_codec.py)

**Coverage:**
- Pack/unpack roundtrips for all 4 formats
- Image resizing
- Monochrome conversion
- Patch application & restore
- Bounds checking

**Run:**
```bash
pytest tests/ -v
```

### Integration Testing (Manual)

1. **Image inspection:**
   ```bash
   baofeng-logo-flasher inspect-img sample.img
   ```

2. **Bitmap discovery:**
   ```bash
   baofeng-logo-flasher scan-logo sample.img
   ```

3. **Offline patching:**
   ```bash
   baofeng-logo-flasher patch-logo sample.img logo.png --offset 0x1000
   ```

4. **Restore from backup:**
   ```bash
   cp backups/*/region_0x001000_*.bin restored_region.bin
   ```

---

## Adding New Features

### Add a New CLI Command

Edit `src/baofeng_logo_flasher/cli.py`:

```python
@app.command()
def my_command(
    arg1: str = typer.Argument(..., help="Description"),
    opt1: int = typer.Option(0, "--option1", "-o", help="Description"),
) -> None:
    """Help text for this command."""
    print_header("My Command")
    
    # Your logic here
    
    print_success("Done!")
```

### Add a New Bitmap Format

Edit `src/baofeng_logo_flasher/logo_codec.py`:

1. Add to `BitmapFormat` enum
2. Implement `_pack_FORMAT()` method
3. Implement `_unpack_FORMAT()` method
4. Add test case in `tests/test_logo_codec.py`

### Add Protocol Support for New Radio Model

Edit `src/baofeng_logo_flasher/protocol/uv5rm_protocol.py`:

1. Add magic bytes to `MAGIC_BYTES` dict
2. Add base type identifiers to `BASE_TYPES` dict
3. Test with `read-clone` command

---

## Debug Logging

Enable verbose logging:

```bash
# Via environment variable
export LOGLEVEL=DEBUG
baofeng-logo-flasher patch-logo ...

# Or in Python
import logging
logging.basicConfig(level=logging.DEBUG)
```

This prints:
- Serial port read/write details
- Image conversion steps
- File I/O operations
- Verification results

---

## Dependency Management

### Core Dependencies

- **pyserial** - Serial port communication (required for radio)
- **pillow** - Image processing (required for logo conversion)
- **typer** - CLI framework (required for commands)
- **rich** - Terminal formatting (required for pretty output)

### Optional Dependencies

- **streamlit** - Web UI (optional, install with `pip install streamlit`)

### Development Dependencies

- **pytest** - Test runner
- **black** - Code formatter
- **ruff** - Linter

---

## Project Maturity Levels

### Phase A: Image Analysis ✅ COMPLETE
- Inspect tool
- Bitmap scanning tool
- Visual discovery workflow

### Phase B: Protocol Verification ✅ COMPLETE
- Verification module
- Documentation
- Safety gates

### Phase C: File Operations ✅ COMPLETE
- Logo codec (all 4 formats)
- Logo patcher (safe + backups)
- Tests (roundtrip, bounds, restore)

### Phase D: Radio Integration 🟡 READY FOR TESTING
- Protocol module (CHIRP extraction)
- CLI read-clone command
- Manual radio I/O

### Phase E: UI ✅ COMPLETE
- Typer CLI (all commands)
- Streamlit web UI (inspection + patching)

---

## Error Handling Philosophy

1. **Fail fast** - Detect issues early
2. **Fail safely** - Always preserve original state
3. **Fail clearly** - Users understand what went wrong and how to fix it

Example:

```python
# BAD: Silent failure
try:
    patch_image(...)
except:
    pass  # ❌ User doesn't know what failed

# GOOD: Clear error with recovery path
try:
    patch_image(...)
except ValueError as e:
    print_error(f"Bounds check failed: {e}")
    print_warning("Restore original region with: cp backup.bin image.bin")
    sys.exit(1)
```

---

## Future Enhancements

Potential areas for development:

1. **Compression support** - If logo region is compressed
2. **Multiple logos** - Handle primary + secondary logo regions
3. **Firmware updates** - Modify other settings besides logo
4. **Batch operations** - Flash multiple radios from one template
5. **CRC/checksum** - Validate patched regions
6. **Radio model detection** - Auto-select logo offset based on detected model

---

## Questions?

See the main README.md or check test files for usage examples.
