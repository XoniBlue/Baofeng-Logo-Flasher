#!/usr/bin/env python3
"""
Test different magic byte sequences to find the right one for your radio.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

import serial
import time

# Different magic byte sequences for various firmware versions
MAGIC_SEQUENCES = {
    'UV5R_ORIG': b"\x50\xBB\xFF\x01\x25\x98\x4D",      # Original firmware
    'UV5R_291': b"\x50\xBB\xFF\x20\x12\x07\x25",       # BFB291+ firmware
    'UV82': b"\x50\xBB\xFF\x20\x13\x01\x05",           # UV-82 radio
    'UV6': b"\x50\xBB\xFF\x20\x12\x08\x23",            # UV-6 radio
    'F11': b"\x50\xBB\xFF\x13\xA1\x11\xDD",            # F-11 radio
    'A58': b"\x50\xBB\xFF\x20\x14\x04\x13",            # A-58 radio
    'UV5G': b"\x50\xBB\xFF\x20\x12\x06\x25",           # UV-5G radio
    'UV6_ORIG': b"\x50\xBB\xFF\x12\x03\x98\x4D",       # UV-6 (original FW)
}

PORTS = ["/dev/cu.Plser", "/dev/cu.URT0"]

def test_magic(port, magic_bytes, name):
    """Test a magic sequence on a port."""
    try:
        ser = serial.Serial(
            port=port,
            baudrate=9600,
            bytesize=8,
            parity='N',
            stopbits=1,
            timeout=1.5,
            write_timeout=1.5,
            rtscts=True,
        )
        
        ser.rts = True
        ser.dtr = True
        time.sleep(0.1)
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        time.sleep(0.1)
        
        # Send magic bytes
        for byte in magic_bytes:
            ser.write(bytes([byte]))
            ser.flush()
            time.sleep(0.01)
        
        # Wait for response
        ack = ser.read(1)
        ser.close()
        
        if ack == b'\x06':
            return "✓ ACK RECEIVED"
        elif ack:
            return f"✗ Got 0x{ack.hex().upper()} instead of 0x06"
        else:
            return "✗ No response"
            
    except Exception as e:
        return f"✗ Error: {e}"

print("Testing different magic byte sequences...\n")

for port in PORTS:
    print(f"{'='*60}")
    print(f"Testing port: {port}")
    print(f"{'='*60}")
    
    for name, magic in MAGIC_SEQUENCES.items():
        result = test_magic(port, magic, name)
        print(f"{name:15} {magic.hex().upper():20} {result}")
    
    print()

print("\nIf you got '✓ ACK RECEIVED' above, that's your magic sequence!")
print("If nothing worked on either port, the radio may not be in bootloader mode.")
print("\nHint: In CHIRP, try:")
print("  1. Radio -> Clone from radio (this enters bootloader)")
print("  2. Or look for a 'Bootloader' or 'Program' menu option")
