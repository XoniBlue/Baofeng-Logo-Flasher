#!/usr/bin/env python3
"""
Quick test script to verify radio connection with corrected protocol.
UV-5RM uses UV17Pro protocol (115200 baud, 16-byte ident magic).
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

import logging
logging.basicConfig(level=logging.DEBUG, format='%(name)s - %(message)s')

from baofeng_logo_flasher.boot_logo import read_radio_id, list_serial_ports, SERIAL_FLASH_CONFIGS

print("Available serial ports:")
ports = list_serial_ports()
for p in ports:
    print(f"  - {p}")

if not ports:
    print("No serial ports found!")
    sys.exit(1)

# Prefer /dev/cu.Plser if available, otherwise use first port
port = "/dev/cu.Plser" if "/dev/cu.Plser" in ports else ports[0]
print(f"\nAttempting to connect to radio at {port}...")

config = SERIAL_FLASH_CONFIGS["UV-5RM"]
print(f"Protocol: UV17Pro (UV-5RM)")
print(f"Baud rate: {config['baudrate']}")
print(f"Ident magic: {config['magic']!r}")

try:
    # Use UV17Pro protocol for UV-5RM
    radio_id = read_radio_id(
        port=port,
        magic=config["magic"],
        baudrate=config["baudrate"],
        timeout=1.5,
        protocol="uv17pro",
        post_ident_magics=config.get("post_ident_magics"),
        fingerprint=config.get("fingerprint", b"\x06"),
    )
    print(f"\n✓ SUCCESS! Radio ID: {radio_id}")
    print("Connection verified - radio is responding correctly!")
except Exception as e:
    print(f"\n✗ FAILED: {e}")
    print("\nTroubleshooting tips:")
    print("1. Ensure the radio is powered on")
    print("2. Ensure the USB cable is properly connected")
    print("3. Close any other serial port applications (CHIRP, Arduino IDE, etc.)")
    print("4. Try a different USB cable")
    sys.exit(1)
