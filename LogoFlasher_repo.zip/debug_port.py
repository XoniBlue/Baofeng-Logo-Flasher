#!/usr/bin/env python3
"""
Debug script to test serial port communication with detailed logging.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

import logging
import serial
import time

# Enable debug logging
logging.basicConfig(level=logging.DEBUG, format='%(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

port = "/dev/cu.Plser"
baudrate = 9600

print(f"Opening port {port} at {baudrate} baud...")

try:
    ser = serial.Serial(
        port=port,
        baudrate=baudrate,
        bytesize=8,
        parity='N',
        stopbits=1,
        timeout=2.0,
        write_timeout=2.0,
        rtscts=True,
    )
    
    # Set control signals
    ser.rts = True
    ser.dtr = True
    
    time.sleep(0.2)
    
    print(f"\n✓ Port opened successfully")
    print(f"  RTS: {ser.rts}")
    print(f"  DTR: {ser.dtr}")
    print(f"  Port is_open: {ser.is_open}")
    
    # Clear buffers
    ser.reset_input_buffer()
    ser.reset_output_buffer()
    
    print(f"\n Buffers cleared, waiting 0.1s...")
    time.sleep(0.1)
    
    # Send magic bytes
    magic = b"\x50\xBB\xFF\x20\x12\x07\x25"
    print(f"\nSending magic bytes: {magic.hex().upper()}")
    
    for i, byte in enumerate(magic):
        print(f"  Sending byte {i+1}/7: 0x{byte:02X}", end="", flush=True)
        ser.write(bytes([byte]))
        ser.flush()
        time.sleep(0.01)
        print(" ✓")
    
    print(f"\nWaiting for ACK (0x06)...")
    
    # Try to read response
    start_time = time.time()
    ack = b""
    
    while len(ack) == 0 and (time.time() - start_time) < 3.0:
        byte = ser.read(1)
        if byte:
            ack = byte
            elapsed = time.time() - start_time
            print(f"✓ Received byte after {elapsed:.3f}s: 0x{byte.hex().upper()}")
            break
        else:
            elapsed = time.time() - start_time
            if int(elapsed) % 1 == 0 and elapsed < 1.5:
                print(f"  Still waiting ({elapsed:.1f}s)...", end="\r", flush=True)
            time.sleep(0.05)
    
    if not ack:
        print(f"\n✗ No response received after 3 seconds")
        print(f"\nTrying to read any available data...")
        ser.timeout = 0.1
        data = ser.read(100)
        if data:
            print(f"Found buffered data: {data.hex().upper()}")
        else:
            print("No data in buffer")
    
    ser.close()
    
except Exception as e:
    print(f"\n✗ Error: {e}")
    import traceback
    traceback.print_exc()
